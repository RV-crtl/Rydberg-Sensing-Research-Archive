# V4.20 | C033 finite-panel recovery and full-Stokes evidence

**Purpose:** Re-run the last missing V4.19 finite state (mask 13), without altering copper geometry or the already solved V4.19 files. Complete a uniform-profile six-switch (states 3,6,8,10,12,13) complex total-field analyser at 1.850 GHz for the **3×3 82×82 mm finite PCB**. No new synthetic noise or fabricated HFSS responses.

## Verified evidence from V4.19 compact return

- All ten finite cases for masks 3,6,8,10,12 (X/Y) converged and exported 252 complex total-vector field samples each.
- Mask 13 X hit the ANSYS Student 64,000-volume-element ceiling: last completed mesh 62,811 tetrahedra; HFSS next attempted mesh 65,815 elements; final Delta Mag Energy 0.35513 (target 0.10); mask13 Y not started.
- Radiation-box comparison for mask3 was within 8.70% in complex transverse ROI fields compared with the older 95-mm clearance domain (provisional 10% threshold).
- Five-state receiver instrument is rank 4 but has normalised condition ~41.37 at 5mm, ~80.53 at 10mm, ~181.91 at 20mm, ~467.63 at 50mm. Adding mask13 might help or might not; no completed finite six-state claim yet.
- Source is native HFSS plane wave, PEC copper switch bridges, no injected noise.

## Instructions

1. **Back up** the existing Windows V4.1 / V4.16 / V4.18 / V4.19 directory.
2. Unzip V4.20 directly over the project root. Existing `scripts/` are merged; original HFSS projects are **not changed**.
3. Double-click `RUN_V420_PREFLIGHT.cmd` (one-time).
4. Double-click **`RUN_V420_AUTOMATIC.cmd`**.
   - First HFSS case: **C033 mask 13, X incidence**, copper max-length 2.7 mm (`P27`).
   - Then mask 13 Y, mask 3 X/Y calibration/control, followed by all remaining masks X/Y.
   - All 12 runs use *one consistent profile*; state13 solved with P27 is NOT silently mixed with V419 COMPACT for the final instrument.
   - If P27 encounters the Student mesh ceiling, an automatic, separately archived P33 profile (3.3 mm surface mesh) is attempted.
5. Upload `RETURN_PACKAGES/RETURN_TO_CHATGPT_V420_*.zip`. Do not upload only `LATEST...PATH.txt`.
6. Optionally run `RUN_V420_NATIVE_PROJECTS_BACKUP.cmd` and retain the resulting `.aedt`/`.aedtresults` archive locally (potentially large).

## What is preserved

- All new native `.aedt` projects, `.aedtresults` and solver settings **locally** under `V420_NATIVE_HFSS/P27` or `/P33`.
- Compact return: `RESULT.json` per solve, raw complex `FIELDS/TOTAL_E.fld`, `.conv`, `.mesh`, `.prof`, native HFSS messages, logs, figures PDF/SVG/PNG, all four plane analyser rows CSV and full Stokes matrices JSON, mesh-effect comparisons, every recorded failure and SHA-256 manifest.
- `V419_NATIVE_HFSS/COMPACT` remains untouched. HFSS comparisons will be reported independently, never fused across two mesh profiles.

## Constraints

- Same C033 11-parameter geometry, six switch configurations, RO4350B-equivalent dielectric and ideal-PEC switch bridge model.
- Same 55-mm XY, 80-mm front and 100-mm rear open-domain clearances.
- Frequency 1.85 GHz; four receiving planes at 5,10,20,50mm behind board; receiver ROI 70×50mm.
- P27 profile: 2.7mm maximum copper mesh length, 2% adapt refinement/pass, 42 maximum passes, 2 consecutive magnetic-energy tolerance passes.
- P33 fallback: 3.3mm maximum copper mesh length, otherwise same setup (48 maximum passes).
- These deliberately coarser meshes may change the fields. Read `REFERENCE_FIELD_COMPARISON.json` and `ALL_SHARED_STATES_MESH_COMPARISON.json` before claiming credibility.
- Full 7×7, 178-mm PCB remains **unverified**. HFSS 3×3 full-Stokes does not automatically prove panel-scale or atomic sensor readout.

## What counts as success

1. 12/12 native HFSS cases converge with actual convergence evidence (not only solver exit=0).
2. Each profile is internally consistent; matrix full rank at specified receiver planes.
3. Report `condition`, min gain, circular coefficient and complete matrix for each plane.
4. Mesh comparison of existing mask3 or other shared states is presented alongside the result.
5. If the finite 3×3 condition >35 or field mesh change >10%, report it explicitly; *do not* turn the figure into a claim of validated performance.

## What if Student still fails?

The return ZIP contains the native project and error diagnostics. The honest next step is to relax domain/mesh settings, reduce solve complexity or use a full HFSS licence, **not** to label an unconverged solution as valid. Do not modify copper to artificially make the last solve pass.
