# HFSS V4.22 — correct the finite plane-wave adaptive stopping condition

**This is a research diagnostic, not a completed validated electromagnetic result.**

## Why V4.22 exists

V4.21 successfully exported all 12 native finite C033 plane-wave HFSS solutions, but the instrument changes substantially between its 2.4 mm mesh and V4.20's 2.7 mm mesh: worst deterministic Stokes calibration-transfer difference **76.92% at 5 mm**, **55.09% at 10 mm**. V4.21's HFSS `.conv` files show **Delta Mag Energy target 0.1**. Reviewing the solver script revealed it set `MaxDeltaS` (used for port/S-parameter stopping), not `MaxDeltaE` (used for plane-wave/incident-wave stopping). Ansys HFSS 2025 R2 scripting documentation explicitly exposes `MaxDeltaE` for this case.

V4.22 changes exactly the *actual* adaptive stopping criterion, plus minimum passes, while preserving the C033 copper polygons, finite radiation domain, 70 × 50 mm receiver area, X/Y plane-wave excitations and total-field exports.

## What it runs

- Profile **E24**: copper surface mesh maximum length 2.4 mm, `MaxDeltaE=0.02`, maximum 42 passes, minimum 8, at least 3 consecutive converged passes, 2% refinement.
- Profile **E27**: copper surface mesh maximum length 2.7 mm, **the same** solver policy.
- Six original switching masks **3, 6, 8, 10, 12, 13**, both X and Y incident polarisation, **1.85 GHz**, 3×3 finite 82×82 mm C033.
- Order starts with problematic cases 12/X, 6/Y and 13/X. The campaign automatically proceeds to the rest only after success.
- Automatic comparison between two *new* strict profiles, plus each profile against its corresponding historical solution. It never mixes results from different profiles into one Stokes matrix.
- Native evidence: complex total E `.fld`, exact adaptive `.conv`, tetrahedra `.mesh`, solution profile `.prof`, project `.aedt` and `.aedtresults` kept on the computer, raw numerical matrices and PDF/SVG/PNG plots.

## Install and run

1. Back up the **existing V4.1 working folder** containing V4.16/V4.18/V4.20/V4.21 and its `V420_NATIVE_HFSS` and `V421_NATIVE_HFSS` folders.
2. Extract this ZIP into that folder (merge `scripts`; don't delete old files).
3. Double-click **`RUN_V422_PREFLIGHT.cmd`** to check geometry and archived results.
4. Double-click **`RUN_V422_STRICT_AUTOMATIC.cmd`**. The run can be long. It saves each successful HFSS project immediately and resumes completed cases on later attempts.
5. Upload the newest **`RETURN_TO_CHATGPT_V422_COMPACT_*.zip`** from `RETURN_PACKAGES` for review.
6. For native `.aedt` + `.aedtresults` preservation, run `RUN_V422_BACKUP_NATIVE_PROJECTS.cmd` (large backup).

If HFSS fails, the controller records the error and returns the completed evidence instead of reporting a scientific pass. A failed case is deliberately **not auto-deleted**; provide the returned ZIP for a correction.

## Interpretation / acceptance

The final `V422_RESULTS/SCIENTIFIC_VERDICT.json` clearly reports the actual native energy criterion in the `.conv` file. It accepts only results with `MaxDeltaE` target **0.02**, all 24 case exports, four-rank receiver instruments, conditioning ≤35 at 5 and 10 mm, matrix variation ≤5%, and worst deterministic cross-mesh Stokes transfer discrepancy ≤10%. These are **engineering acceptance thresholds**, not universal statements of experimental accuracy.

If both strict profiles converge but disagree, the next issue is electromagnetic receiver-field mesh refinement and near-field spatial sampling. A small adaptive energy change alone does **not** guarantee field-point convergence.

## Preservation and scope

No fabricated or simulated noise is added. In the paper, clearly describe these as **HFSS finite near-field predictions for an ideal PEC 82×82 mm panel**, not final 178×178 mm fabrication, real PIN diode or atomic EIT measurement. The archive stores every numerical datum needed for later publication plots. The 2.4 and 2.7 mm labels refer to *requested copper-surface maximum element length*, not the achieved minimum tetrahedron size.

### User's paper direction

Keep experimental linear polariser, earlier windmill/circular work, C000 → C033/C015 optimisation, L-band full-Stokes matrices, HFSS Poincaré reconstruction, finite-panel response, and separately the derived equations. Do not report the optional full-board simulations as completed unless actual HFSS results exist.
