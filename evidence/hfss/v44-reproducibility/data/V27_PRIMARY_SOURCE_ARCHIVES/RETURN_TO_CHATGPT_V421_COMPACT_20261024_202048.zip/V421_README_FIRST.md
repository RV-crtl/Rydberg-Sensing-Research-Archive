# HFSS V4.21 | C033 finite near-field independent-mesh confirmation

## Scientific rationale

V4.20 successfully solved all 12 finite 3×3 C033 X/Y simulations at 1.850 GHz. The **row-normalised** six-state Stokes matrix at 5 mm has condition 24.7245 and rank four; 10 mm condition 24.8223. However, compared with V4.19 2.0-mm copper mesh, native complex receiver fields differ by as much as 63.62% near the board, particularly in states 6 and 12. This is a legitimate numerical uncertainty even without added noise or hardware imperfections. We must not call V4.20 mesh-independent yet.

## Run
1. Back up your working V4.1/V4.16/V4.18/V4.19/V4.20 folder.
2. Extract this ZIP into that **same working project root**. Do not delete V420_NATIVE_HFSS or V419_NATIVE_HFSS.
3. Run `RUN_V421_PREFLIGHT.cmd` and confirm 12/12 native V4.20 P27 reference cases are visible.
4. Run `RUN_V421_MESH_CONFIRM.cmd`. It processes the two most mesh-sensitive states (6Y and 12X) first, then all 12 cases for an independently adapted complete P24 instrument.
5. Upload `RETURN_PACKAGES/RETURN_TO_CHATGPT_V421_COMPACT_*.zip`.
6. Optional: `RUN_V421_BACKUP_NATIVE_PROJECTS.cmd` retains a separate potentially large archive of projects and their solver results.

All existing C033 copper polygons, six switches, excitation, samples and radiation clearances are **unchanged**. P24 copper surface mesh max length is 2.4 mm versus P27's 2.7 mm. Adaptive refinement settings match P27, including 2% per pass and the same Delta Mag Energy convergence configuration. Student licence limits may prevent a finer solve; the runner stops safely on an HFSS error and still packs the partial evidence.

## Exact acceptance and scope

- `PASS_DUAL_MESH_NEAR_FIELD` requires both finite six-state matrices to have rank four and normalised condition <=35 at 5 and 10 mm, 5% maximum row-normalised instrument matrix drift, and worst noiseless Stokes-calibration transfer <=10%.
- Raw complex field differences are reported **independently**, not hidden by the matrix gate. Neither rank four nor machine-precision inversion from the same matrix independently establishes convergence.
- The measured observable is a **uniform average of the squared X-component of total electric field** across a 70x50 mm ROI, not an EIT/AT atomic simulation.
- Scope: 82x82 mm finite 3x3 aperture, one frequency (1.850 GHz), ideal PEC switches, specified radiation boundaries, native HFSS complex total fields, no synthetic noise. The manufacturing-scale 178x178 mm board remains unsolved.
- Never combine V420 P27 state responses and V421 P24 state responses into a six-state analyser. Each profile is evaluated separately.

## Research-data preservation

`V421_RESULTS/SCIENTIFIC_COMPARISON.json`, exact Stokes analyser rows for both profiles (derived from raw `.fld` files), all field differences, independent calibration-transfer results, PDF/SVG/PNG plots, `.conv/.mesh/.prof`, solver messages and logs are preserved. Native `.aedt` projects and `.aedtresults` remain under `V421_NATIVE_HFSS/P24`. A compact return intentionally omits large original native projects, but includes complex `.fld` exports and diagnostic files.

**Results in BASELINE_V420 are genuine earlier HFSS evidence; they are not new V4.21 HFSS solves.**
