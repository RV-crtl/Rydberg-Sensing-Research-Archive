@echo off
setlocal
cd /d "%~dp0"
py -3.11 scripts\inspect_return.py
set "RC=%ERRORLEVEL%"
pause
endlocal & exit /b %RC%
