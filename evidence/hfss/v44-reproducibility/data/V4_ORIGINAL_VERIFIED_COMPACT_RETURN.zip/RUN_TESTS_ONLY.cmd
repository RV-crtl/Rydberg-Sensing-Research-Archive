@echo off
setlocal
cd /d "%~dp0"
py -3.11 -u scripts\setup_env.py
if errorlevel 1 exit /b 4
".venv\Scripts\python.exe" -m unittest discover -s tests -v
set "RC=%ERRORLEVEL%"
pause
endlocal & exit /b %RC%
