import unittest, json, tempfile, sys, subprocess, pathlib, zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import launcher_v4
class TestLauncherRegression(unittest.TestCase):
 def test_cmd_has_no_piped_title(self):
  c=(ROOT/'RUN_AUTOMATIC.cmd').read_text()
  self.assertIn('%comspec%',c.lower())
  self.assertIn('/K',c)
  self.assertNotIn('title Rydberg Single-PCB HFSS V4 |',c)
 def test_scientific_script_unchanged_solver_hooks(self):
  s=(ROOT/'scripts'/'campaign_v4.py').read_text()
  self.assertIn('SCIENTIFIC_VERDICT.json',s)
  self.assertIn("solve('EMPTY'",s)
 def test_startup_bundle_is_independently_readable(self):
  z=launcher_v4.startup_bundle('REGRESSION_TEST_ONLY', {'test': True})
  self.assertTrue(z.is_file())
  with zipfile.ZipFile(z) as archive:
   self.assertIsNone(archive.testzip())
   self.assertIn('SHA256_MANIFEST.json', archive.namelist())
   self.assertIn('LOGS/V4_1_STARTUP_DIAGNOSTICS.json', archive.namelist())
  z.unlink()
if __name__=='__main__': unittest.main()
