import unittest,sys,json,math,zipfile,tempfile,hashlib
from pathlib import Path
import numpy as np
from shapely.geometry import Polygon
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from pcb_geometry import config,shapes,preflight,svg,dxf,get_shapes
from physics import analyzer_row,stokes
from campaign_v4 import score,best_sixteen_subset,contiguous_band
C=config()

class TestGeometry(unittest.TestCase):
 def test_four_families_sixteen_masks(self):self.assertEqual(len(preflight()),64)
 def test_two_faces_and_bounds(self):
  for v in range(4):
   for m in range(16):
    p=shapes(v,m)
    self.assertEqual(set(x['layer'] for x in p),{'TOP','BOTTOM'})
    self.assertEqual(set(x['z'] for x in p),{-.8,.8})
    self.assertEqual(len(p),len({x['name'] for x in p}))
    for o in p:
     self.assertTrue(Polygon(o['polygon']).is_valid)
     self.assertTrue(all(max(abs(x),abs(y))<11.95 for x,y in o['polygon']))
 def test_four_gaps_are_real_switches(self):
  for v in range(4):
   for lay in ('TOP','BOTTOM'):
    for mask,expected in ((0,3),(15,1)):
     u=unary_union([Polygon(o['polygon']) for o in shapes(v,mask) if o['layer']==lay])
     count=len(u.geoms) if hasattr(u,'geoms') else 1
     self.assertEqual(count,expected,(v,lay,mask,count))
 def test_masks_unique_and_switch_area_does_not_decrease(self):
  for v in range(4):
   ids=set()
   for m in range(16):
    s=shapes(v,m);ids.add(tuple(sorted(o['name'] for o in s)))
    self.assertGreaterEqual(sum(o['area_mm2'] for o in s),50)
   self.assertEqual(len(ids),16)
 def test_native_baseline_identical_to_v3_geometry(self):
  from v3_geometry_control import shapes as old
  oldc=json.loads((ROOT/'V3_BASELINE_CONFIG.json').read_text())
  for m in range(16):
   self.assertEqual(shapes(3,m),old(2,m,oldc))
 def test_dxf_svg_and_references(self):
  self.assertIn('<svg',svg('SINGLEPCB',0,1))
  self.assertIn('POLYLINE',dxf('SINGLEPCB',1,2))
  self.assertEqual(get_shapes('EMPTY',0,0),[])
  self.assertEqual(set(x['layer'] for x in get_shapes('U_BASELINE',0,0)),{'TOP'})
 def test_board_dimensions(self):
  b=C['board'];self.assertEqual(b['cells_x']*b['unit_cell_mm'],168)
  self.assertEqual(b['panel_outline_mm'],178)
  self.assertEqual(b['edge_clearance_mm'],5)

class TestMeasurement(unittest.TestCase):
 def test_jones_stokes_consistency(self):
  rng=np.random.default_rng(6)
  for _ in range(20):
   J=rng.standard_normal((2,2)) + 1j*rng.standard_normal((2,2))
   e=rng.standard_normal(2)+1j*rng.standard_normal(2)
   for model,W in [('axis_x',np.diag([1,0])),('axis_y',np.diag([0,1])),('total_power',np.eye(2))]:
    observed=np.vdot(J@e,W@(J@e)).real
    estimated=analyzer_row(J,model)@stokes(e)
    self.assertAlmostEqual(observed,estimated,places=9)
 def test_ideal_polarimeter_is_rank_four(self):
  x=np.array([1,0],complex);y=np.array([0,1],complex)
  d=(x+y)/math.sqrt(2);a=(x-y)/math.sqrt(2)
  r=(x+1j*y)/math.sqrt(2);l=(x-1j*y)/math.sqrt(2)
  J=[np.outer(x,u.conj()) for u in [x,y,d,a,r,l]]
  A=np.array([analyzer_row(j,'axis_x') for j in J]);q=score(A)
  self.assertEqual(q['rank'],4)
  self.assertLess(q['cond'],4)
 def test_weak_states_fail(self):
  chosen=best_sixteen_subset([np.eye(2,dtype=complex)]*16,'axis_x',6)
  self.assertFalse(chosen['passed'])
 def test_contiguous_band_requires_five(self):
  rows=[{'freq_GHz':1.6+i*.025,'passed':i in (2,3,4,5,6),'cond':5} for i in range(12)]
  self.assertEqual(len(contiguous_band(rows)),1)
 def test_historical_v3_source(self):
  d=json.loads((ROOT/'V3_BEST_CANDIDATE_1P8.json').read_text())
  self.assertAlmostEqual(d['cond'],120.91483446262401)
 def test_scientific_verdict_not_automatically_passed(self):
  p=ROOT/'RESULTS'/'SCIENTIFIC_VERDICT.json'
  if p.exists():
   d=json.loads(p.read_text());self.assertIn('success',d)
   if d['success']:self.assertEqual(d['status'],'PERIODIC_HFSS_PASS_FINITE_PANEL_AND_HARDWARE_UNVERIFIED')

class TestPyaedtAPI(unittest.TestCase):
 def test_complex_parser_against_mock(self):
  from hfss_compat_v21 import fetch_matrix
  names=['S(DST:1,SRC:1)','S(DST:1,SRC:2)','S(DST:2,SRC:1)','S(DST:2,SRC:2)']
  vals=[.75+.05j,.2-.04j,-.11+.09j,.45+.02j]
  class Data:
   primary_sweep_values=['1.8GHz'];units_sweeps={}
   def __init__(self,k):self.k=k
   def data_real(self,k):return [vals[names.index(k)].real]
   def data_imag(self,k):return [vals[names.index(k)].imag]
  class Post:
   def get_solution_data(self,expressions,**kw):return Data(expressions)
  class App:
   post=Post()
   def get_traces_for_plot(self,category):return names
  d,e=fetch_matrix(App(),'Setup1 : RF_Sweep',[1.8]);self.assertEqual(len(d),1)
  self.assertAlmostEqual(d[0]['t_jones_2x2_complex'][0][1][0],0.2)
 def test_mandatory_solver_hooks(self):
  s=(ROOT/'scripts'/'hfss_single_case.py').read_text()
  for term in ('app.analyze()','create_floquet_port','fetch_matrix(','CASE_FAILURE.json','source_sha256'):
   if term=='create_floquet_port':
    self.assertIn(term,(ROOT/'scripts'/'hfss_compat_v21.py').read_text())
   else:self.assertIn(term,s)

class TestPackaging(unittest.TestCase):
 def test_standard_zip_verifies_sha256(self):
  from inspect_return import validate_zip
  with tempfile.TemporaryDirectory() as td:
   zp=Path(td)/'demo.zip';body=b'valid numerical diagnostic data'
   with zipfile.ZipFile(zp,'w') as z:
    z.writestr('RESULTS/SCIENCE.json',body)
    z.writestr('SHA256_MANIFEST.json',json.dumps({'RESULTS/SCIENCE.json':hashlib.sha256(body).hexdigest()}))
   ok=validate_zip(zp);self.assertEqual(ok['status'],'VALID')
   with zipfile.ZipFile(zp,'w') as z:
    z.writestr('RESULTS/SCIENCE.json',b'corrupted')
    z.writestr('SHA256_MANIFEST.json',json.dumps({'RESULTS/SCIENCE.json':hashlib.sha256(body).hexdigest()}))
   with self.assertRaises(RuntimeError):validate_zip(zp)

if __name__=='__main__':unittest.main()
