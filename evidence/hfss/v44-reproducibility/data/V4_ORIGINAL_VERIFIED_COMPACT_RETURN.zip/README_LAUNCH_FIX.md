# V4.1 – Fixed Windows launcher (23 October 2026)

## Run
1. Extract **the entire ZIP** to `C:\HFSS_V4_1` (never launch from within a ZIP preview).
2. Double-click `RUN_AUTOMATIC.cmd` or `START_HERE.cmd`. The command window **remains open** even after errors.
3. The launcher creates `LOGS/V4_1_LAUNCHER.log`, `LOGS/V4_1_SETUP.log`, `LOGS/V4_1_OFFLINE_TESTS.log`, and `LOGS/V4_1_HFSS_CAMPAIGN.log` as it advances.
4. On setup failure, send `RETURN_PACKAGES/RETURN_TO_CHATGPT_V4_STARTUP_FAILURE_*.zip`. If **no Python command exists at all**, the persistent console explains how to install it; there cannot be a Python-generated ZIP until Python is available.
5. If HFSS gets far enough, send `RETURN_PACKAGES/RETURN_TO_CHATGPT_SINGLEPCB_V4_COMPACT_*.zip`.

The previous RUN_AUTOMATIC.cmd contained an unescaped `|` in `title`; Windows treated this as a command pipe. That parsing defect is removed. The new version uses `cmd /D /K` to keep its console open, automatically detects a 64-bit Python 3.11 executable, and logs every stage.

Exit codes: **0** = application reported success, **3** = HFSS campaign or scientific acceptance gate failed (inspect `RESULTS/SCIENTIFIC_VERDICT.json`), **4** = Python/bootstrap/offline-test failure. Exit 0 does not independently prove physical performance.

The numerical geometry and HFSS solver scripts are unchanged from V4. This patch fixes the Windows launch/recovery workflow; it does **not** claim new HFSS data.

## Standalone bootstrap health check
`py -3 scripts\launcher_v4.py selftest` creates a verified example startup diagnostics ZIP without starting HFSS.
