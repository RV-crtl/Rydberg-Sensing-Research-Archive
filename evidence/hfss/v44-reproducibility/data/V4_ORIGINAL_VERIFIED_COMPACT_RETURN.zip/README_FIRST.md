# V4 | Single-PCB Rydberg polarisation analyser | Ansys HFSS

**STATUS:** Geometry and software prepared. **NO NEW HFSS ELECTROMAGNETIC RESULTS IN THIS RELEASE.**

## Fast start

**V4.1 launcher fix:** read `README_LAUNCH_FIX.md`. If the window disappeared in V4, use the new `RUN_AUTOMATIC.cmd`; persistent console and startup error ZIP are now provided.


1. Extract this complete ZIP to a short writable folder, for example `C:\HFSS_V4` (not OneDrive).
2. Run `RUN_AUTOMATIC.cmd`. Requires Windows, Ansys Electronics Desktop HFSS 2025.2 Student, Python 3.11 x64, internet for first-time Python dependency installation.
3. The runner performs dependency/setup checks, geometry/physics regression tests, native Floquet solves, solver-based state selection, independent-mesh and frequency steps *only when scientifically justified*.
4. The runner **always attempts to generate** two return archives, even on scientific failure. Inspect `RESULTS\SCIENTIFIC_VERDICT.json` and `RETURN_PACKAGES\LATEST_COMPACT_PATH.txt`.
5. Double-click `INSPECT_RETURN.cmd` to test ZIP CRC **and** all file SHA256 checksums. Then upload the latest `RETURN_TO_CHATGPT_SINGLEPCB_V4_COMPACT_*.zip` here. The full ZIP is optional unless we need native project debugging.

If `RUN_AUTOMATIC.cmd` fails before setup, it creates a `RETURN_TO_CHATGPT_SETUP_FAILURE_*.zip` with setup logs. If it fails after setup, check `LOGS\PACKAGE_FAILURE.txt`. The raw JSON evidence remains in `RESULTS` regardless of ZIP creation.

## Technical design

- **One board:** 178 × 178 mm outline; seven by seven 24 mm periodic cells (168 × 168 mm copper-pattern area); 5 mm border.
- **Substrate:** nominal 1.60 mm RO4350B-equivalent, εr=3.48 and tanδ=0.0037; copper initially represented by infinitesimally thin PEC sheets.
- **Candidates:** V0 serpentine omega-like, V1 complementary split-loop, V2 crossed meander, V3 exact geometry control copied from previous V3 **variant 2**.
- **States:** four ideal conductor bridges per unit cell, 16 logical masks; independently switched simultaneously in all 49 cells. Hardware bias lines, solder pads, lumped-diode models and vias are NOT installed in this first electromagnetic screen.
- **Primary frequency:** 1.800 GHz; central-band diagnostic 1.600–2.000 GHz, 25 MHz sample spacing; exploratory 1.300–2.300 GHz.
- **Receiver:** fixed output modal X projection as primary surrogate; Y and total-power diagnostics are secondary. Actual Rydberg atomic EIT response and volumetric optical readout are NOT modelled.

## Scientific pipeline

0. Empty-box Floquet calibration and single-sided U-shaped control benchmark.
1. 4 families × 16 masks = 64 native 1.8 GHz HFSS switch-state solves (restartable; 2 references).
2. Extract **complex** two-input/two-output Floquet coefficients and calculate Jones matrices, not just |S21| in dB.
3. Select optimal SIX independent switch measurements per candidate, prioritising primary fixed-X response. Compare against the measured historical V3 condition 120.9148.
4. Require rank 4, row-gain-normalised condition ≤35, circular metric ≥0.08 and average normalized power ≥0.015. These are engineering screening thresholds, not promised device specifications. Synthetic 1% detector-noise sensitivity is reported separately.
5. If 1.8 GHz primary screen fails, still attempt a 1.6–2.0 GHz **diagnostic frequency sweep** on its best candidate (budget permitting). This is *not* reported as a validated working band.
6. If 1.8 GHz screen passes, independently refine the HFSS mesh; compare matrices and Stokes reconstruction, then validate contiguous frequency samples. Only with those gates passed will the extended sweep be run.
7. `RUN_FINITE_ROI_OPTIONAL.cmd` is an optional high-cost finite 7×7 panel plane-wave field simulation. It is explicitly excluded from first-pass design claims.

### Output hierarchy

- `HFSS_PROJECTS/*/*.aedt`: native AEDT projects, once solved on Windows.
- `HFSS_PROJECTS/*/RESULT.json`: signed complex Jones transmission at actual simulated frequencies.
- `RESULTS/SCREEN_V*_1P8.json`: instrument matrices from actual solver data.
- `RESULTS/BEST_CANDIDATE_1P8.json`: best six-state fixed-X candidate.
- `RESULTS/V3_TO_V4_COMPARISON.json`: historical baseline vs V4 analysis.
- `RESULTS/INDEPENDENT_MESH.json`, `RESULTS/FINE_POLARIMETRIC_BAND.csv` if reached.
- `RESULTS/SCIENTIFIC_VERDICT.json`: the only campaign-level pass/fail truth.
- `RETURN_PACKAGES/RETURN_TO_CHATGPT_SINGLEPCB_V4_COMPACT_*.zip`: small readable archive containing all JSON, CAD, code, plots and logs, including each case's JSON metadata (not 200MB native solver cache).
- `RETURN_PACKAGES/RETURN_TO_CHATGPT_SINGLEPCB_V4_FULL_*.zip`: additionally includes native AEDT project/cache files; use only when full reproduction is necessary.

**Read `docs/SCIENTIFIC_SCOPE.md` before interpreting performance.**

## What may fail

The V4 geometries are testable design hypotheses, not proven full-Stokes analysers. We deliberately include the frozen V3 geometry control to detect solver/calibration changes. HFSS Student meshing limits may prevent the finite panel simulation. The ongoing simulation cannot validate manufactured PIN diodes, biasing or optical EIT performance. For independent research replication, preserve the project and return ZIPs.
