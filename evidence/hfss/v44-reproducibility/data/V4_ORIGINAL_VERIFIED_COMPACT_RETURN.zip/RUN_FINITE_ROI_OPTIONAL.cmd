@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Run RUN_AUTOMATIC.cmd first & pause & exit /b 4)
".venv\Scripts\python.exe" -u scripts\finite_panel_v3.py
set "RC=%ERRORLEVEL%"
".venv\Scripts\python.exe" -u scripts\campaign_v4.py pack
pause
endlocal & exit /b %RC%
