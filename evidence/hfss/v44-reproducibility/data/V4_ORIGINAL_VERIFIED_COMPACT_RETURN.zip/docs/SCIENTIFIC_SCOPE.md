# Scientific scope, interpretation, and reference designs

The task is to enable electromagnetic research, not to assert that an unsimulated copper pattern solves full-Stokes polarimetry. The candidate patterns are original research hypotheses inspired by established resonant FSS, active reconfigurable unit cells, and Jones/Mueller polarimetry; they **are not exact reproductions** of published dimensions or a verified PIN-biased device.

## Literature / engineering precedents

- 2021 IEEE Access U-shaped FSS with L-band linear polarisation filtering near 1.83 GHz, doi:10.1109/ACCESS.2021.3060155. Motivates a compact U-control, not full-Stokes proof.
- Reconfigurable polarization converters with PIN-enabled resonant states, *IEEE Antennas and Wireless Propagation Letters* 23 (2024), DOI 10.1109/LAWP.2024.3350034. This reports reflection-based higher-frequency operation; **not** proof of our low-band transmission architecture.
- *Full-Stokes metasurface polarimetry requiring only a single measurement*, Photonics Research (2024), DOI 10.1364/PRJ.512204. Validates alternative spatially resolved approaches, not a one-scalar passive device.
- Native HFSS Floquet ports / PyAEDT API reference: https://aedt.docs.pyansys.com/version/stable/API/_autosummary/ansys.aedt.core.hfss.Hfss.create_floquet_port.html

## Measurement physics

For each switch state k, calibrated Jones transmission J_k and detector weighting W, a scalar intensity-like measurement obeys m_k = e† J_k† W J_k e. With a consistent Jones/Stokes convention, m = A S; each row of A follows from Q_k=J_k† W J_k. `scripts/physics.py` has algebra verified against direct complex-field calculations.

**Caution 1:** the measured atomic EIT/Autler–Townes output may not obey a direct intensity-response law, so this is only a photometric/vector analyser surrogate until you calibrate the atomic response. Atomic receiver sensitivity can depend on dipole orientation, saturation, RF amplitude, detuning, and spatial variation.

**Caution 2:** the Floquet port eigenmodes need independent calibration to physical laboratory Ex/Ey axes and propagation conventions (especially S3 handedness). An empty-box unitary correction alone does not guarantee handedness.

**Caution 3:** a single static PCB with one scalar receiver measurement cannot recover arbitrary four-component Stokes information. Switch states here provide *multiple sequential* measurements. Each cell receives the same switch command; viable bias routing and real PIN packages must be engineered later.

**Caution 4:** infinite-array periodic transmission is **not** the 178 mm finite-aperture result; edge diffraction and optical sampling of the Rb cell remain unproven.

## Screening criteria

- Full rank 4 and row-gain-normalised matrix condition ≤35 at 1.800 GHz (a screening threshold chosen for numerical headroom, not a universal physical constant).
- Circular sensitivity ≥0.08 and average normalized unpolarized response ≥0.015.
- Independent-mesh matrix change ≤5% and worst reconstruction error ≤10% when comparing independent meshes.
- At least 5 **consecutive HFSS samples** passing around 1.8 GHz to claim a sampled usable frequency interval. Report precise sample resolution (25 MHz) and do not interpolate between failed or missing samples.
- An experimental claim requires real-switch/copper loss models, finite-panel fields, and calibrated EIT performance; none is pre-populated here.

The fixed-X primary detector choice is inherited from the V3 comparison. Using the fixed-Y result to declare the intended fixed-X setup successful would be invalid.

## Frequency/size tradeoff

At 1.8 GHz, λ0 ≈ 166.6 mm and the 178 mm panel is only ≈1.07 λ0 wide. A small illuminated fraction and finite-edge effects must be considered before publication. The target 1.6–2.0 GHz interval is a goal, not a claim; no broadband performance is asserted without native HFSS frequency data.
