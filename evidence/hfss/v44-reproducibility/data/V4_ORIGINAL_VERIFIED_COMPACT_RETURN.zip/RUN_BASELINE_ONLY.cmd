@echo off
setlocal
cd /d "%~dp0"
py -3.11 -u scripts\setup_env.py
if errorlevel 1 exit /b 4
".venv\Scripts\python.exe" -u scripts\hfss_single_case.py --design EMPTY --stage PILOT
if errorlevel 1 goto ERROR
".venv\Scripts\python.exe" -u scripts\hfss_single_case.py --design SINGLEPCB --variant 3 --mask 7 --stage PILOT
if errorlevel 1 goto ERROR
".venv\Scripts\python.exe" -u scripts\campaign_v4.py pack
pause
endlocal & exit /b 0
:ERROR
".venv\Scripts\python.exe" -u scripts\campaign_v4.py pack
pause
endlocal & exit /b 2
