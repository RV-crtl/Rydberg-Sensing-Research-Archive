"""Transparent Jones -> Stokes power-analyser physics; no HFSS results manufactured.

Stokes convention: S=[|Ex|²+|Ey|², |Ex|²-|Ey|²,
                         2Re(Ex conj(Ey)), 2Im(Ex conj(Ey))].
A scalar, polarization-insensitive receiver observes ||J e||²,
where J is the two-mode transmitted Jones matrix, and the analyser
row is constructed from Q=J^H J. All power is dimensionless incident normalized.
"""
from __future__ import annotations
import numpy as np


def analyzer_row(jones, detector="total_power"):
    """Stokes row for detector m=||W^(1/2) J e||².

    axis_x/axis_y use the OUTPUT Floquet port modal axes, which must
    be calibrated against physical laboratory Ex/Ey before interpreting S3.
    """
    j=np.asarray(jones,dtype=complex)
    if j.shape!=(2,2): raise ValueError('Jones matrix must be complex 2x2')
    if detector=="total_power":
        W=np.eye(2)
    elif detector=="axis_x":
        W=np.diag([1.,0.])
    elif detector=="axis_y":
        W=np.diag([0.,1.])
    else: raise ValueError("Invalid detector model: "+str(detector))
    q=j.conj().T@W@j
    return np.array([np.trace(q).real/2,(q[0,0]-q[1,1]).real/2,
                     q[0,1].real,q[0,1].imag],float)


def stokes(e):
    x,y=np.asarray(e,dtype=complex)
    return np.array([abs(x)**2+abs(y)**2,abs(x)**2-abs(y)**2,
                     2*np.real(x*np.conj(y)),2*np.imag(x*np.conj(y))],float)


def score_matrix(A):
    A=np.asarray(A,dtype=float)
    s=np.linalg.svd(A,compute_uv=False)
    rank=int(np.linalg.matrix_rank(A,tol=1e-10))
    row_gains=np.maximum(A[:,0],1e-12)
    B=A/row_gains[:,None]
    sb=np.linalg.svd(B,compute_uv=False)
    cond=float(sb[0]/sb[-1]) if sb[-1]>1e-12 else 1e12
    return dict(rank=rank,cond=cond,condition_censored_at_1e12=bool(sb[-1]<=1e-12),singular_values=sb.tolist(),
                circular_sensitivity=float(np.max(np.abs(B[:,3]))),
                row_gains=row_gains.tolist(),
                avg_transmission=float(np.mean(A[:,0])),
                normalized_instrument_determinant_abs=float(abs(np.linalg.det(B))))


def reconstruction(A, heldout=None):
    """Algebraic self-consistency, *not* an independent HFSS mesh validation."""
    if heldout is None:
        rng=np.random.default_rng(9123)
        vectors=[]
        for _ in range(192):
            z=rng.normal(size=2)+1j*rng.normal(size=2)
            vectors.append(stokes(z/np.linalg.norm(z)))
        heldout=np.array(vectors)
    A=np.asarray(A,float)
    y=heldout@A.T
    rec=y@np.linalg.pinv(A).T
    err=np.linalg.norm(rec-heldout,axis=1)/np.maximum(np.linalg.norm(heldout,axis=1),1e-12)
    return dict(algebraic_max_error=float(err.max()),algebraic_p95=float(np.percentile(err,95)),
                label='SAME-MATRIX algebraic test; does not establish independent EM reconstruction')


def compact_score(row):
    if row['rank']<4 or not np.isfinite(row['cond']):return 1e8
    return float(np.log1p(row['cond']) + 6*max(0,.08-row['circular_sensitivity'])
                 + 2*max(0,.08-row['avg_transmission']))


def complex_pair(z):return [float(np.real(z)),float(np.imag(z))]
def unpack_pair(p):return complex(*p)
def pack_jones(J):return [[complex_pair(v) for v in row] for row in np.asarray(J)]
def unpack_jones(J):return np.array([[unpack_pair(v) for v in row] for row in J],complex)
