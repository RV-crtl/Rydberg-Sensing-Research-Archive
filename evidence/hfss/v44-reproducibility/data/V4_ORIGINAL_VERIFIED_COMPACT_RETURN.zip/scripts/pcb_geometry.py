"""V4 exploratory doubly metallised metasurface families for HFSS.

All polygons are constructive geometry HYPOTHESES, not validated resonant
polarizers, exact literature replicas, or manufacturing-ready diode layouts.
4 ideal switches per unit cell (2 on each face). Copper is represented as
2D PEC sheets. Numerical values are in mm.
"""
from __future__ import annotations
import json,re,math
from pathlib import Path
from shapely.geometry import LineString, Polygon,box
from shapely.affinity import rotate,scale
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]
SAFE=re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')

def config():return json.loads((ROOT/'config.json').read_text(encoding='utf8'))

def _components(obj,face,z,prefix):
    if obj.is_empty: return []
    if obj.geom_type=='Polygon':parts=[obj]
    elif obj.geom_type=='MultiPolygon':parts=list(obj.geoms)
    else:raise ValueError(f'Expected Polygon, received {obj.geom_type}: {prefix}')
    out=[]
    for i,p in enumerate(parts):
        name=f'{prefix}_{i:02d}'
        if not SAFE.fullmatch(name):raise ValueError('Invalid HFSS object name '+name)
        if p.interiors or not p.is_valid or p.area<0.02:raise ValueError('Invalid trace or void: '+name)
        points=[(float(x),float(y)) for x,y in list(p.exterior.coords)[:-1]]
        if len(points)<3 or any(max(abs(x),abs(y))>=11.95 for x,y in points):
            raise ValueError('Copper outside 24mm unit-cell safety area: '+name)
        out.append({'name':name,'layer':face,'z':z,'polygon':points,'area_mm2':float(p.area)})
    return out

def _local_gap(path,width,fraction,along=1.8):
    """Finite-width cutting strip normal to the centreline at a path arclength.

    along = length of conductor excised. Transverse width covers all copper.
    """
    line=LineString(path);dist=line.length*fraction
    x,y=line.interpolate(dist).coords[0]
    a=line.interpolate(max(0,dist-0.05)).coords[0]
    b=line.interpolate(min(line.length,dist+0.05)).coords[0]
    vx,vy=b[0]-a[0],b[1]-a[1];n=math.hypot(vx,vy);vx/=n;vy/=n
    nx,ny=-vy,vx;long=along/2;wide=(width+0.7)/2
    pts=[(x+vx*long+nx*wide,y+vy*long+ny*wide),
         (x+vx*long-nx*wide,y+vy*long-ny*wide),
         (x-vx*long-nx*wide,y-vy*long-ny*wide),
         (x-vx*long+nx*wide,y-vy*long+ny*wide)]
    return Polygon(pts)

def _face(path,width,angle,mirror,shrink,mask,bits,face,z,tag):
    # All gaps placed before transformation to ensure accurate rotated cutting.
    trace=LineString(path).buffer(width/2,cap_style=2,join_style=2,quad_segs=6)
    # Explicit gap positions: separated by > one full grid arm.
    cuts=[_local_gap(path,width,t) for t in (0.18,0.78)]
    def transform(obj):
        if mirror:obj=scale(obj,xfact=-1,yfact=1,origin=(0,0))
        obj=scale(obj,xfact=shrink,yfact=shrink,origin=(0,0))
        return rotate(obj,angle,origin=(0,0))
    trace=transform(trace);cuts=[transform(x) for x in cuts]
    off=trace.difference(unary_union(cuts))
    objects=_components(off,face,z,tag+'_TRACE')
    for bit,cut in zip(bits,cuts):
        if mask&(1<<bit):
            restore=trace.intersection(cut.buffer(0.16,join_style=2))
            objects+=_components(restore,face,z,tag+'_SWITCH_'+str(bit))
    return objects

def shapes(variant:int,mask:int,cfg=None):
    cfg=cfg or config()
    if not (0<=variant<4 and 0<=mask<=15):raise ValueError('variant 0..3 and mask 0..15 required')
    h=cfg['board']['thickness_mm']
    if variant==3:
        # Frozen original V3 best geometry: controls for modelling changes.
        from v3_geometry_control import shapes as v3_shapes
        c3=json.loads((ROOT/'V3_BASELINE_CONFIG.json').read_text(encoding='utf8'))
        return v3_shapes(2,mask,c3)
    if variant==0:
        # Nested continuous serpentine-U conductor on top; rotated C on bottom.
        top=[(-9,-8.4),(-9,8.4),(-5,8.4),(-5,-3),(0,-3),
             (0,8.4),(5,8.4),(5,-8.4),(9,-8.4)]
        rear=[(-6.6,-7),(-6.6,7),(6.6,7),(6.6,-4),(1.0,-4),(1.0,3)]
        tw,bw,angle,mir,shrink=1.05,1.05,30,False,.86
    elif variant==1:
        # Asymmetric complementary split loops on opposing faces.
        top=[(-9,-8),(-9,8),(9,8),(9,-8),(-5,-8)]
        rear=[(-7,-6.9),(7,-6.9),(7,6.9),(-7,6.9),(-7,-2.6)]
        tw,bw,angle,mir,shrink=1.2,1.05,40,True,.87
    else:
        # Longer meandered double-face conductive paths (candidate for L-band
        # miniaturisation, NOT a claimed quarter-wave element).
        top=[(-9,-8.5),(-9,8.5),(-4.6,8.5),(-4.6,-5.3),
             (0,-5.3),(0,8.5),(4.6,8.5),(4.6,-5.3),(9,-5.3),(9,8.5)]
        rear=[(-8,-7.5),(-8,7.5),(-3.8,7.5),(-3.8,-4.3),
              (1,-4.3),(1,7.5),(6,7.5),(6,-7.5)]
        tw,bw,angle,mir,shrink=1.0,1.0,55,True,.77
    return _face(top,tw,0,False,1.,mask,(0,1),'TOP',h/2,'FRONT')+\
           _face(rear,bw,angle,mir,shrink,mask,(2,3),'BOTTOM',-h/2,'REAR')

def u_baseline(cfg=None):
    from v3_geometry_control import u_baseline as legacy
    c3=json.loads((ROOT/'V3_BASELINE_CONFIG.json').read_text(encoding='utf8'))
    return legacy(c3)

def get_shapes(design,variant,mask,cfg=None):
    if design=='EMPTY':return []
    if design=='U_BASELINE':return u_baseline(cfg)
    if design=='SINGLEPCB':return shapes(variant,mask,cfg)
    raise ValueError('Unsupported design '+design)

def preflight():
    c=config();b=c['board'];r=[]
    assert b['cells_x']*b['unit_cell_mm']==b['pattern_area_mm']
    assert b['panel_outline_mm']-b['pattern_area_mm']==2*b['edge_clearance_mm']
    for v in range(4):
        names=set()
        for m in range(16):
            sh=shapes(v,m,c)
            if not sh:raise ValueError('Empty geometry')
            if set(p['layer'] for p in sh)!={'TOP','BOTTOM'}:raise ValueError('Not two copper faces')
            if len({s['name'] for s in sh})!=len(sh):raise ValueError('Duplicate HFSS names')
            for p in sh:
                if abs(p['z'])!=b['thickness_mm']/2:raise ValueError('Wrong copper Z')
                if not Polygon(p['polygon']).is_valid:raise ValueError('Invalid copper polygon')
            sig=tuple(sorted(p['name'] for p in sh))
            if sig in names:raise ValueError('Duplicate mask topology')
            names.add(sig)
            r.append({'variant':v,'mask':m,'family':c['design']['families'][v],
                      'objects':len(sh),'top_area_mm2':round(sum(p['area_mm2'] for p in sh if p['layer']=='TOP'),4),
                      'rear_area_mm2':round(sum(p['area_mm2'] for p in sh if p['layer']=='BOTTOM'),4)})
    return r

def svg(design,variant,mask,cfg=None):
    items=get_shapes(design,variant,mask,cfg)
    out=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="-12 -12 24 24" width="960" height="960">',
         '<rect x="-12" y="-12" width="24" height="24" fill="#e5e9ec"/>']
    for e in items:
        pts=' '.join(f'{x:.6f},{-y:.6f}' for x,y in e['polygon'])
        color='#b9752c' if e['layer']=='TOP' else '#287c9c'
        opacity='1.0' if e['layer']=='TOP' else '.5'
        out.append(f'<polygon points="{pts}" fill="{color}" fill-opacity="{opacity}" stroke="#242e3a" stroke-width=".035"/>')
    out.append('</svg>')
    return '\n'.join(out)

def dxf(design,variant,mask,cfg=None):
    sh=get_shapes(design,variant,mask,cfg)
    lines=['0','SECTION','2','HEADER','9','$INSUNITS','70','4','0','ENDSEC','0','SECTION','2','ENTITIES']
    for e in sh:
        lines+=['0','POLYLINE','8',e['layer'],'66','1','70','1']
        for x,y in e['polygon']:
            lines+=['0','VERTEX','8',e['layer'],'10',str(x),'20',str(y),'30',str(e['z'])]
        lines+=['0','SEQEND']
    return '\n'.join(lines+['0','ENDSEC','0','EOF'])+'\n'
