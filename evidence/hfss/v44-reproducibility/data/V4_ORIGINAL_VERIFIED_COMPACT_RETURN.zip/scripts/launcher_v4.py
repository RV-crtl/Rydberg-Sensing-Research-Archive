"""Fail-visible, audited V4 Windows bootstrap. Stdlib only; no HFSS required to launch.

Runs the original physics pipeline *unchanged*. Errors create an independent readable
return ZIP even if the V4 Python venv cannot be installed. NEVER marks science as passed.
"""
from __future__ import annotations
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import traceback
import zipfile
import argparse

ROOT = Path(__file__).resolve().parents[1]
LOG_DIR = ROOT / "LOGS"
RETURN_DIR = ROOT / "RETURN_PACKAGES"
LOG_DIR.mkdir(exist_ok=True)
RETURN_DIR.mkdir(exist_ok=True)
LOGFILE = LOG_DIR / "V4_1_LAUNCHER.log"


def say(*items):
    msg = " ".join(str(x) for x in items)
    print(msg, flush=True)
    with LOGFILE.open("a", encoding="utf-8") as f:
        f.write(msg + "\n")


def discover_python311():
    possible = []
    if os.name == 'nt':
        possible += [["py", "-3.11"], ["python"], ["python3.11"]]
    else:
        possible += [["python3.11"], ["python"]]
    checked = []
    for argv in possible:
        try:
            out = subprocess.run(argv + ["-c", "import sys,struct;print(str(sys.version_info.major)+'.'+str(sys.version_info.minor)+'-'+str(struct.calcsize('P')*8))"],
                                 capture_output=True, text=True, timeout=15, check=False)
            checked.append({'command': argv, 'return_code': out.returncode,
                            'stdout': out.stdout.strip(), 'stderr': out.stderr.strip()[:300]})
            if out.returncode == 0 and out.stdout.strip() == "3.11-64":
                return argv, checked
        except (OSError, subprocess.TimeoutExpired) as ex:
            checked.append({'command': argv, 'error': repr(ex)})
    return None, checked


def run_stream(argv, label):
    say("\n=====", label, "=====", " ".join(map(str, argv)))
    with (LOG_DIR / ("V4_1_" + label + ".log")).open('w', encoding='utf-8', errors='replace') as f:
        proc = subprocess.Popen([str(a) for a in argv], cwd=str(ROOT), stdin=None,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, encoding='utf-8', errors='replace', bufsize=1)
        for line in proc.stdout:
            print(line, end='', flush=True)
            f.write(line)
            f.flush()
        code = proc.wait()
    say(label, "EXIT_CODE", code)
    return code


def startup_bundle(reason, facts):
    now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d_%H%M%S')
    outfile = RETURN_DIR / ('RETURN_TO_CHATGPT_V4_STARTUP_FAILURE_' + now + '.zip')
    files = [p for p in sorted(LOG_DIR.rglob('*')) if p.is_file()]
    files += [ROOT / name for name in (
        'RUN_AUTOMATIC.cmd', 'START_HERE.cmd', 'README_LAUNCH_FIX.md',
        'requirements.txt', 'config.json', 'RELEASE_MANIFEST.json') if (ROOT / name).is_file()]
    text = json.dumps({'status': 'STARTUP_FAILURE', 'reason': str(reason),
                       'time_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       'platform': platform.platform(), 'details': facts,
                       'scientific_results': 'NONE_CLAIMED'}, indent=2, default=str)
    (LOG_DIR / 'V4_1_STARTUP_DIAGNOSTICS.json').write_text(text, encoding='utf-8')
    files.append(LOG_DIR / 'V4_1_STARTUP_DIAGNOSTICS.json')
    manifest = {}
    with zipfile.ZipFile(outfile, mode='w', compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(set(files)):
            name = p.relative_to(ROOT).as_posix()
            data = p.read_bytes()
            z.writestr(name, data)
            manifest[name] = hashlib.sha256(data).hexdigest()
        z.writestr('SHA256_MANIFEST.json', json.dumps(manifest, indent=2))
        z.writestr('READ_ME_FIRST_RETURN_SUMMARY.json', json.dumps({'reason': str(reason), 'science_pass': False}, indent=2))
    # Independently open and verify file CRC + SHA256; no HFSS dependency.
    with zipfile.ZipFile(outfile) as z:
        assert z.testzip() is None
        for name, sha in manifest.items():
            assert hashlib.sha256(z.read(name)).hexdigest() == sha
    say('STARTUP ZIP CREATED AND VERIFIED:', outfile)
    return outfile


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=['run', 'selftest'], nargs='?', default='run')
    args = p.parse_args()
    fact = {'bootstrap_interpreter': sys.executable, 'bootstrap_version': sys.version,
            'project': str(ROOT), 'cwd': os.getcwd()}
    say('V4.1 launcher started', datetime.datetime.now(datetime.timezone.utc).isoformat())
    try:
        candidate, checks = discover_python311()
        fact['python311_discovery'] = checks
        if args.action == 'selftest':
            startup_bundle('SELFTEST_ONLY_NO_HFSS_RUN', fact)
            return 0
        if candidate is None:
            raise RuntimeError('Python 3.11 (64-bit) is not installed/discoverable. ' +
                               'This HFSS project requires Python 3.11 x64; other versions cannot replace it.')
        say('Using Python 3.11:', ' '.join(candidate))
        if run_stream(candidate + ['-u', str(ROOT / 'scripts' / 'setup_env.py')], 'SETUP') != 0:
            raise RuntimeError('Environment setup failed; see LOGS/V4_1_SETUP.log')
        venv = ROOT / '.venv' / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
        if not venv.exists():
            raise RuntimeError('Python environment was not created: ' + str(venv))
        if run_stream([venv, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], 'OFFLINE_TESTS') != 0:
            raise RuntimeError('Offline tests failed; no HFSS campaign started')
        code = run_stream([venv, '-u', ROOT / 'scripts' / 'campaign_v4.py', 'run'], 'HFSS_CAMPAIGN')
        if code != 0:
            # Code 3 is expected when the physics gates fail; do not mark a setup failure.
            if code == 3:
                say('SCIENTIFIC GATE NOT MET (exit 3); diagnostics are in RETURN_PACKAGES.')
            else:
                say('Campaign returned an execution error, exit', code)
            if not list(RETURN_DIR.glob('RETURN_TO_CHATGPT_SINGLEPCB_V4_COMPACT_*.zip')):
                startup_bundle('CAMPAIGN_FAILED_WITHOUT_COMPACT_RETURN', {**fact, 'campaign_exit_code': code})
        else:
            say('Campaign returned exit 0. Confirm scientific verdict in RESULTS/SCIENTIFIC_VERDICT.json.')
        return code
    except Exception as exc:
        say('LAUNCH FAILED:', repr(exc))
        say(traceback.format_exc())
        try:
            startup_bundle(str(exc), fact)
        except Exception:
            say('DIAGNOSTIC ZIP CREATION FAILED:', traceback.format_exc())
        return 4


if __name__ == '__main__':
    sys.exit(main())
