"""V4 native HFSS Floquet solve; no manufactured EM result files."""
from __future__ import annotations
import argparse,sys,os,json,hashlib,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from pcb_geometry import get_shapes,config
from hfss_compat_v21 import mk_floquet,fetch_matrix

def write(p,d):
 p=Path(p);p.parent.mkdir(exist_ok=True,parents=True)
 p.write_text(json.dumps(d,indent=2,allow_nan=False,default=str)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser();p.add_argument('--design',choices=['SINGLEPCB','U_BASELINE','EMPTY'],required=True)
 p.add_argument('--variant',type=int,default=0);p.add_argument('--mask',type=int,default=0)
 p.add_argument('--stage',choices=['PILOT','REFINE','FINE','EXTENDED'],required=True)
 a=p.parse_args();c=config();board=c['board'];solver=c['solver'];s=c['screening']
 if a.stage=='PILOT':freq=[1.8]
 elif a.stage=='REFINE':freq=[1.8]
 elif a.stage=='FINE':freq=s['fine_GHz']
 else:freq=s['extended_GHz']
 copper=get_shapes(a.design,a.variant,a.mask,c)
 ident=f'{a.design}_V{a.variant:02d}_M{a.mask:02d}_{a.stage}'
 loc=ROOT/'HFSS_PROJECTS'/ident;loc.mkdir(exist_ok=True,parents=True)
 project=loc/(ident+'.aedt');meta={
 'name':ident,'status':'START','source':'NATIVE_ANSYS_HFSS_SOLVED_COMPLEX_S_PARAMETERS',
 'design':a.design,'variant':a.variant,'mask':a.mask,'stage':a.stage,
 'frequency_request_GHz':freq,'project':str(project),
 'source_sha256':{str(p.relative_to(ROOT)):sha(p) for p in
     [ROOT/'scripts'/'hfss_single_case.py',ROOT/'scripts'/'pcb_geometry.py',ROOT/'scripts'/'v3_geometry_control.py',ROOT/'scripts'/'hfss_compat_v21.py',ROOT/'config.json',ROOT/'V3_BASELINE_CONFIG.json']},
 'models_excluded':['PIN equivalent-circuit parasitics','DC bias and vias','edge diffraction','finite Rb vapour-cell optical response', 'real metal conductivity and 35um finite thickness']}
 write(loc/'START.json',meta)
 app=None
 try:
  from ansys.aedt.core import Hfss
  ver=c.get('aedt_version');st=any(os.environ.get(k) for k in ['ANSYSEMSV_ROOT252','ANSYSEMSV_ROOT251','ANSYSEMSV_ROOT261','ANSYSEMSV_ROOT242'])
  app=Hfss(project=str(project),design='ONE_PCB_FULL_STOKES',solution_type='Modal',version=ver,
           non_graphical=False,new_desktop=True,close_on_exit=False,student_version=st)
  app.modeler.model_units='mm'
  dielectric=app.materials.add_material('RO4350B_EQUIVALENT')
  dielectric.permittivity=board['epsilon_r'];dielectric.dielectric_loss_tangent=board['tan_delta']
  P=board['unit_cell_mm'];h=board['thickness_mm'];za=solver['air_half_height_mm']
  if not app.modeler.create_box([-P/2,-P/2,-h/2],[P,P,h],name='SINGLE_PCB_SUBSTRATE',material='RO4350B_EQUIVALENT'):
   raise RuntimeError('PCB substrate creation failed')
  for g in copper:
   obj=app.modeler.create_polyline([[x,y,g['z']] for x,y in g['polygon']],close_surface=True,
                 cover_surface=True,name=g['name'],material='vacuum')
   if not obj:raise RuntimeError('Copper creation failed '+g['name'])
   if not app.assign_perfect_e(obj.name,name='PEC_'+obj.name):raise RuntimeError('Failed ideal copper boundary '+obj.name)
  air=app.modeler.create_box([-P/2,-P/2,-za],[P,P,2*za],name='AIR_FLOQUET',material='vacuum')
  if not air:raise RuntimeError('Floquet surrounding region failed')
  mk_floquet(app,air,P,za,-za)
  setup=app.create_setup('Setup1');setup.props['Frequency']='1.8GHz'
  setup.props['MaximumPasses']=solver['max_adaptive_passes']+(4 if a.stage=='REFINE' else 0)
  setup.props['MinimumPasses']=solver['min_adaptive_passes']
  setup.props['MinimumConvergedPasses']=2
  setup.props['MaxDeltaS']=solver['refine_max_delta_s'] if a.stage=='REFINE' else solver['max_delta_s']
  setup.props['PercentRefinement']=10 if a.stage=='REFINE' else 15;setup.update()
  if len(freq)==1:
    sw=setup.create_single_point_sweep(unit='GHz',freq=freq[0],name='RF_Sweep',save_fields=a.stage=='REFINE')
  else:
    sw=app.create_linear_count_sweep(setup='Setup1',unit='GHz',start_frequency=freq[0],
      stop_frequency=freq[-1],num_of_freq_points=len(freq),name='RF_Sweep',
      sweep_type='Discrete',save_fields=False)
  if not sw:raise RuntimeError('HFSS RF sweep construction failed')
  app.save_project()
  if not bool(app.validate_simple()):raise RuntimeError('HFSS reported invalid model')
  if app.analyze() is False:raise RuntimeError('HFSS analyze returned false')
  app.save_project()
  data,expressions=fetch_matrix(app,'Setup1 : RF_Sweep',freq)
  meta.update(status='HFSS_SOLVED_COMPLEX_2X2',frequency_results=data,expressions=expressions,
       copper_polygon_count=len(copper),two_faces_mm=[-h/2,h/2],
       note='Floquet axes and handedness require independent lab-frame calibration')
  write(loc/'RESULT.json',meta)
  print('HFSS_SUCCEEDED',ident,flush=True)
  return 0
 except Exception as e:
  meta.update(status='HFSS_FAILED',error=repr(e),traceback=traceback.format_exc())
  write(loc/'CASE_FAILURE.json',meta);print(meta['traceback'],flush=True)
  return 2
 finally:
  if app:
   try:app.save_project()
   except Exception:pass
   try:app.release_desktop(close_projects=True,close_desktop=True)
   except Exception:pass
if __name__=='__main__':sys.exit(main())
