"""HFSS V4 restartable, budgeted, SCIENCE-GATED one-PCB polarimeter campaign.

Only HFSS results from RESULT.json are treated as EM evidence. Ideal-vector and
Gaussian-noise checks are mathematical tests and are explicitly labelled.
"""
from __future__ import annotations
import os,sys,json,datetime,time,subprocess,traceback,zipfile,hashlib,itertools,csv,argparse,shutil
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from pcb_geometry import config,preflight,svg,dxf
from physics import analyzer_row,unpack_jones,stokes
C=config();SC=C['screening'];SOL=C['solver']; R=ROOT/'RESULTS';L=ROOT/'LOGS';D=ROOT/'RETURN_PACKAGES'
for d in (R,L,D,ROOT/'CAD',ROOT/'FIGURES',ROOT/'HFSS_PROJECTS'):d.mkdir(exist_ok=True,parents=True)
T0=time.monotonic();BUDGET=float(SOL['campaign_budget_hours'])*3600

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(p,obj):
 p=Path(p);p.parent.mkdir(exist_ok=True,parents=True)
 tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(obj,indent=2,allow_nan=False,default=str)+'\n',encoding='utf8');tmp.replace(p)
def filehash(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def log(event,**kw):
 obj={'utc':now(),'event':event,**kw}
 with (L/'EVENTS.jsonl').open('a',encoding='utf8') as f:f.write(json.dumps(obj,default=str)+'\n')
 print('V4_EVENT:',event,json.dumps(kw,default=str)[:600],flush=True)

def run_name(design,variant,mask,stage):return f'{design}_V{variant:02d}_M{mask:02d}_{stage}'
def project_dir(design,variant,mask,stage):return ROOT/'HFSS_PROJECTS'/run_name(design,variant,mask,stage)
def result_ok(design,variant,mask,stage):
 p=project_dir(design,variant,mask,stage);q=p/'RESULT.json'
 if not q.exists() or not (p/(run_name(design,variant,mask,stage)+'.aedt')).exists():return False
 try:
  d=json.loads(q.read_text());expected={'hfss_single_case.py','pcb_geometry.py','v3_geometry_control.py','hfss_compat_v21.py','config.json','V3_BASELINE_CONFIG.json'}
  for k,v in d['source_sha256'].items():
   if Path(k).name in expected and filehash(ROOT/k)!=v:return False
  return d['status']=='HFSS_SOLVED_COMPLEX_2X2' and d['stage']==stage
 except Exception:return False

def solve(design,variant,mask,stage):
 if result_ok(design,variant,mask,stage):log('RESUME_SOLVED',case=run_name(design,variant,mask,stage));return True
 name=run_name(design,variant,mask,stage)
 old=project_dir(design,variant,mask,stage)
 if old.exists() and any(old.glob('*.aedt')):
  # Important: AEDT *opens* existing project paths. Rebuilding inside an old
  # failed or source-mismatched project would duplicate CAD / ports / setups.
  stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
  dest=ROOT/'STALE_HFSS_CASES'/(name+'_'+stamp)
  dest.parent.mkdir(exist_ok=True,parents=True)
  shutil.move(str(old),str(dest))
  log('ARCHIVED_STALE_HFSS_PROJECT',original=name,archive=str(dest))
 seconds_left=BUDGET-(time.monotonic()-T0)
 if seconds_left<90:raise RuntimeError('BUDGET_REACHED before '+name)
 limit=min(seconds_left-45,float(SOL['case_timeout_minutes'])*60)
 cmd=[sys.executable,'-u',str(ROOT/'scripts'/'hfss_single_case.py'),
      '--design',design,'--variant',str(variant),'--mask',str(mask),'--stage',stage]
 log('HFSS_START',case=name,limit_seconds=round(limit))
 file=L/(name+'.log')
 try:
  with file.open('w',encoding='utf8') as f:
   # Redirect to disk to avoid Windows pipe deadlocks during verbose AEDT logging.
   p=subprocess.Popen(cmd,cwd=str(ROOT),stdout=f,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NEW_PROCESS_GROUP',0))
   try:ret=p.wait(timeout=limit)
   except subprocess.TimeoutExpired:
    log('HFSS_TIMEOUT',case=name)
    p.kill();p.wait(timeout=20)
    raise RuntimeError('HFSS case exceeded deadline '+name+' - see LOGS/'+file.name)
  if ret!=0 or not result_ok(design,variant,mask,stage):
   raise RuntimeError('HFSS case failed '+name+' (exit '+str(ret)+'), inspect '+file.name)
  log('HFSS_SOLVED',case=name)
  return True
 except Exception:
  log('HFSS_FATAL',case=name,traceback=traceback.format_exc()[-6000:])
  raise

def jones(design,var,mask,stage,f=1.8):
 fdata=json.loads((project_dir(design,var,mask,stage)/'RESULT.json').read_text())
 e=next((p for p in fdata['frequency_results'] if abs(p['frequency_GHz']-f)<0.0002),None)
 if e is None:raise RuntimeError('Missing measured HFSS point '+str((design,var,mask,stage,f)))
 return unpack_jones(e['t_jones_2x2_complex'])

def get_calibration(stage='PILOT',f=1.8):
 j=jones('EMPTY',0,0,stage,f);u,s,vh=np.linalg.svd(j)
 if min(s)<.2:raise RuntimeError('Empty-reference Floquet calibration singular')
 return u@vh

def score(A):
 A=np.asarray(A,float);G=np.maximum(A[:,0],1e-12)
 B=A/G[:,None];sing=np.linalg.svd(B,compute_uv=False)
 r={'rank':int(np.linalg.matrix_rank(B,tol=1e-9)),
    'cond':float(sing[0]/sing[-1]) if sing[-1]>1e-12 else 1e12,
    'singular_values':sing.tolist(),
    'circular_sensitivity':float(np.max(np.abs(B[:,3]))),
    'avg_transmission':float(np.mean(A[:,0])),
    'row_gains':A[:,0].tolist()}
 # IMPORTANT: reconstruct with RAW matrix A, not row-normalized B.
 r['minimum_unpolarized_response']=float(A[:,0].min())
 r['min_singular_value_normalized']=float(np.linalg.svd(A/G[:,None],compute_uv=False)[-1])
 return r

def best_sixteen_subset(Js,model,subset_size=6):
 """Exhaustive independent measured states, minimizing physically relevant condition.

 Requires at least 4 rows for four Stokes DOF. Reports if no well-conditioned
 subset exists instead of substituting a theoretical or synthetic Jones matrix.
 """
 rows=np.array([analyzer_row(J,model) for J in Js],float)
 best=None
 for subset in itertools.combinations(range(len(rows)),subset_size):
  A=rows[list(subset)]
  if np.min(A[:,0])<=1e-10:continue
  q=score(A)
  # Selection penalizes inadequate S3 contrast/received power as well as condition.
  loss=(np.log1p(q['cond'])+8*max(0,SC['min_normalized_circular_sensitivity']-q['circular_sensitivity'])
         +5*max(0,SC['min_mean_unpolarized_response']-q['avg_transmission']))
  if q['rank']<4:loss+=15
  if best is None or loss<best['objective']:
   best={'states':list(subset),'model':model,'objective':float(loss),
     'A_real':A.tolist(),**q}
 if best is None:raise RuntimeError('No physically measurable subset '+model)
 best['passed']=bool(best['rank']==4 and best['cond']<=SC['desired_condition_max']
   and best['circular_sensitivity']>=SC['min_normalized_circular_sensitivity']
   and best['avg_transmission']>=SC['min_mean_unpolarized_response'])
 return best

def select_states(var,cal):
 Js=[cal.conj().T@jones('SINGLEPCB',var,m,'PILOT') for m in range(16)]
 rec={'variant':var,'freq_GHz':1.8,'data_source':'HFSS_COMPLEX_FLOQUET',
   'calibration':'Empty-box unitary, modal axes not independently lab calibrated',
   'result':[]}
 for model in SC['detectors']:
  for count in (6,8):
   x=best_sixteen_subset(Js,model,count)
   rec['result'].append(x)
 save(R/f'SCREEN_V{var:02d}_1P8.json',rec)
 return rec

def synthetic_noise(A,n=512):
 rng=np.random.default_rng(38291)
 E=rng.normal(size=(n,2))+1j*rng.normal(size=(n,2));E/=np.linalg.norm(E,axis=1,keepdims=True)
 St=np.array([stokes(e) for e in E]);A=np.asarray(A,float)
 m=St@A.T
 m+=rng.normal(size=m.shape)*float(C['validation']['synthetic_detector_noise_rms_fraction'])*A[:,0]
 Shat=m@np.linalg.pinv(A).T
 err=np.linalg.norm(Shat-St,axis=1)/np.linalg.norm(St,axis=1)
 return {'type':'SYNTHETIC_TEST_VECTORS_AND_DETECTOR_NOISE_USING_REAL_HFSS_INSTRUMENT_MATRIX',
 'median_relative_error':float(np.median(err)),'p95_relative_error':float(np.percentile(err,95)),
 'max_relative_error':float(np.max(err))}

def independent_mesh(var,sel,cal):
 states=sel['states'];model=sel['model']
 for mask in states:solve('SINGLEPCB',var,mask,'REFINE')
 A_coarse=np.asarray(sel['A_real'],float)
 A_fine=np.asarray([analyzer_row(cal.conj().T@jones('SINGLEPCB',var,k,'REFINE'),model) for k in states])
 matrix_drift=float(np.linalg.norm(A_fine-A_coarse)/(np.linalg.norm(A_coarse)+1e-12))
 rng=np.random.default_rng(601);E=rng.normal(size=(256,2))+1j*rng.normal(size=(256,2));E/=np.linalg.norm(E,axis=1,keepdims=True)
 St=np.array([stokes(e) for e in E]);out=St@A_fine.T
 rec=out@np.linalg.pinv(A_coarse).T
 errors=np.linalg.norm(St-rec,axis=1)/np.linalg.norm(St,axis=1)
 report={'source':'TWO_INDEPENDENT_HFSS_MESHES',
    'relative_matrix_drift':matrix_drift,'p95_reconstruction_error':float(np.percentile(errors,95)),
    'worst_reconstruction_error':float(np.max(errors)),
    'status':'PASS' if matrix_drift<=C['validation']['maximum_normalized_matrix_change']
       and max(errors)<=C['validation']['maximum_cross_mesh_relative_stokes_error'] else 'FAIL'}
 save(R/'INDEPENDENT_MESH.json',report)
 return report

def sample_band(var,sel,cal,stage='FINE'):
 f_list=SC['fine_GHz'] if stage=='FINE' else SC['extended_GHz']
 for mask in sel['states']:solve('SINGLEPCB',var,mask,stage)
 solve('EMPTY',0,0,stage)
 rows=[]
 for f in f_list:
  fcal=get_calibration(stage,f)
  A=np.asarray([analyzer_row(fcal.conj().T@jones('SINGLEPCB',var,k,stage,f),sel['model']) for k in sel['states']])
  m=score(A);m.update(freq_GHz=f,
    passed=bool(m['rank']==4 and m['cond']<=SC['desired_condition_max']
    and m['circular_sensitivity']>=SC['min_normalized_circular_sensitivity']
    and m['avg_transmission']>=SC['min_mean_unpolarized_response']))
  rows.append(m)
 result={'stage':stage,'source':'REAL_HFSS_COMPLEX_DISCRETE_FREQUENCY_SWEEP',
  'states':sel['states'],'receiver':sel['model'],'rows':rows,
  'warning':'Sampled frequency points; do not interpolate scientific claims without HFSS verification'}
 save(R/(stage+'_POLARIMETRIC_BAND.json'),result)
 with (R/(stage+'_POLARIMETRIC_BAND.csv')).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=['freq_GHz','passed','rank','cond','circular_sensitivity','avg_transmission','minimum_unpolarized_response'])
  w.writeheader();w.writerows([{k:r[k] for k in w.fieldnames} for r in rows])
 return result

def contiguous_band(rows):
 good=[r for r in rows if r['passed']]
 runs=[];curr=[]
 for r in rows:
  if r['passed']:curr.append(r)
  elif curr:runs.append(curr);curr=[]
 if curr:runs.append(curr)
 runs=[x for x in runs if len(x)>=SC['min_contiguous_passing_samples']]
 return [{'start_GHz':x[0]['freq_GHz'],'stop_GHz':x[-1]['freq_GHz'],
       'samples':len(x),'max_cond':max(y['cond'] for y in x)} for x in runs]

def charts():
 try:
  import matplotlib;matplotlib.use('Agg')
  import matplotlib.pyplot as plt
  for stage in ('FINE','EXTENDED'):
   file=R/(stage+'_POLARIMETRIC_BAND.json')
   if not file.exists():continue
   d=json.loads(file.read_text());freq=[r['freq_GHz'] for r in d['rows']];cond=[r['cond'] for r in d['rows']]
   fig,ax=plt.subplots(figsize=(8,4.6));ax.semilogy(freq,cond,'o-',label='HFSS analyser');ax.axhline(SC['desired_condition_max'],ls='--',label='Accept limit')
   ax.set(xlabel='Frequency (GHz)',ylabel='Row-normalised Stokes condition number',title=f'Actual HFSS: {stage} screening')
   ax.grid(True,alpha=.3);ax.legend();fig.tight_layout();fig.savefig(ROOT/'FIGURES'/(stage+'_condition.png'),dpi=180);plt.close(fig)
 except Exception:(L/'FIGURE_ERROR.txt').write_text(traceback.format_exc(),encoding='utf8')

def package():
 """Always write a small readable results ZIP; optionally separate large AEDT ZIP.

 Self-check ZIP CRC and a SHA256 manifest for each input file before publishing.
 A raw result JSON also remains alongside the archives in RESULTS/.
 """
 stamp=datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
 for category in ('COMPACT','FULL'):
  out=D/f'RETURN_TO_CHATGPT_SINGLEPCB_V4_{category}_{stamp}.zip'
  items=[]
  for name in ('scripts','tests','docs','CAD','FIGURES','RESULTS','LOGS'):
   items.extend(p for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in str(p))
  items.extend(ROOT/name for name in ('README_FIRST.md','config.json','V3_BASELINE_CONFIG.json',
    'V3_BEST_CANDIDATE_1P8.json','requirements.txt','RUN_AUTOMATIC.cmd','RUN_TESTS_ONLY.cmd',
    'RUN_BASELINE_ONLY.cmd','RUN_FINITE_ROI_OPTIONAL.cmd','INSPECT_RETURN.cmd',
    'START_HERE.cmd','README_LAUNCH_FIX.md') if (ROOT/name).exists())
  for f in (ROOT/'HFSS_PROJECTS').rglob('*'):
   if not f.is_file() or f.name.endswith('.lock'):continue
   if f.name in ('START.json','RESULT.json','CASE_FAILURE.json') or category=='FULL':
    items.append(f)
  if category=='FULL':
   items.extend(f for f in (ROOT/'HFSS_FINITE_ROI').rglob('*') if f.is_file()) if (ROOT/'HFSS_FINITE_ROI').exists() else None
  items=sorted(set(items));manifest={p.relative_to(ROOT).as_posix():filehash(p) for p in items}
  verdict_path=R/'SCIENTIFIC_VERDICT.json'
  verdict=json.loads(verdict_path.read_text()) if verdict_path.exists() else {'status':'NOT_EXECUTED'}
  with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as z:
   for f in items:z.write(f,f.relative_to(ROOT).as_posix())
   z.writestr('READ_ME_FIRST_RETURN_SUMMARY.json',json.dumps({'created_utc':now(),
    'verdict':verdict,'zip_type':category,'payload_file_count':len(items)},indent=2))
   z.writestr('SHA256_MANIFEST.json',json.dumps(manifest,indent=2))
  with zipfile.ZipFile(out) as z:
   bad=z.testzip()
   if bad is not None:raise RuntimeError('Corrupt ZIP entry '+bad)
   saved=json.loads(z.read('SHA256_MANIFEST.json'))
   for name,expected in saved.items():
    if hashlib.sha256(z.read(name)).hexdigest()!=expected:
     raise RuntimeError('SHA256 mismatch '+name)
  log('PACKED_AND_VERIFIED',category=category,path=str(out),files=len(items),size=out.stat().st_size)
  if category=='COMPACT':
   (D/'LATEST_COMPACT_PATH.txt').write_text(str(out)+'\n',encoding='utf8')
 latest={'created_utc':now(),'paths':[str(p) for p in sorted(D.glob('RETURN_TO_CHATGPT_SINGLEPCB_V4_*.zip'))]}
 save(D/'LATEST_RETURN.json',latest)

def create_cad():
 rows=preflight()
 for var in range(len(C['design']['families'])):
  for mask in range(16):
   for fmt,fun in (('svg',svg),('dxf',dxf)):
    (ROOT/'CAD'/f'SINGLEPCB_V{var:02d}_M{mask:02d}.{fmt}').write_text(fun('SINGLEPCB',var,mask,C),encoding='utf8')
 for design in ('U_BASELINE','EMPTY'):
  for fmt,fun in (('svg',svg),('dxf',dxf)):
   (ROOT/'CAD'/f'{design}.{fmt}').write_text(fun(design,0,0,C),encoding='utf8')
 save(R/'CAD_PREFLIGHT.json',{'status':'PASS_OFFLINE_CAD','cases':rows,
  'notice':'Geometry checks do not imply solderable bias routing, diode models or EM functionality'})

def run():
 verdict={'status':'STARTED','success':False,'timestamp_utc':now(),
 'physical_design':'ONE_1P6MM_DOUBLE_SIDED_PCB','target_frequency_GHz':1.8,
 'claimed_HFSS_data':'NONE_UNTIL_NATIVE_SOLVER_FILES_EXIST',
 'publication_ready':False,'finite_panel_validated':False,'real_diode_modeled':False}
 try:
  create_cad();log('CAD_PASS',cases=64)
  solve('EMPTY',0,0,'PILOT');solve('U_BASELINE',0,0,'PILOT')
  cal=get_calibration('PILOT')
  candidates=[]
  for var in range(min(SOL['max_variant_count'],len(C['design']['families']))):
   for mask in C['design']['pilot_masks']:solve('SINGLEPCB',var,mask,'PILOT')
   screen=select_states(var,cal)
   for record in screen['result']:
    record['variant']=var
    record['synthetic_noise']=synthetic_noise(record['A_real'])
    candidates.append(record)
   save(R/'ALL_CANDIDATES_1P8.json',candidates)
   good=[p for p in candidates if p['passed'] and p['model']=='axis_x']
   if good:break
  # Only the fixed-X modal receiver is eligible for the *primary* science gate;
  # total-power and axis-Y models remain informative secondary diagnostics.
  primary=[x for x in candidates if x['model']=='axis_x' and len(x['states'])==6]
  best=min(primary,key=lambda x:(not x['passed'],x['cond'],-x['circular_sensitivity']))
  save(R/'BEST_CANDIDATE_1P8.json',best)
  benchmark=json.loads((ROOT/'V3_BEST_CANDIDATE_1P8.json').read_text())
  save(R/'V3_TO_V4_COMPARISON.json',{
   'frequency_GHz':1.8,
   'basis':'Each uses a six-state fixed-X, row-gain-normalized instrument matrix',
   'v3_control_reference_condition':benchmark['cond'],
   'v4_best_condition':best['cond'],
   'v4_best_family':C['design']['families'][best['variant']],
   'relative_condition_change_percent':100*(best['cond']/benchmark['cond']-1),
   'warning':'V3 reference from historical HFSS. V4 cases are new solver results only if the native RESULT.json projects exist.'})
  verdict.update(status='1P8_SCREENED',
    best_variant=best['variant'],best_states=best['states'],best_detector_model=best['model'],
    best_condition=best['cond'],best_rank=best['rank'],best_circular_sensitivity=best['circular_sensitivity'],
    passes_1p8=best['passed'])
  if not best['passed']:
   verdict.update(status='FIXED_AXIS_STOKES_GATE_FAILED',
     reason='No fixed-X high-quality full-Stokes response at 1.8GHz; no broadband or device claim')
   # Generate a useful frequency-resolved *failure* diagnostic, without
   # misrepresenting it as a validated bandwidth. The simulation may be too
   # expensive for the remaining student-HFSS budget: keep the core verdict.
   try:
    diagnostic=sample_band(best['variant'],best,cal,'FINE')
    verdict['diagnostic_fine_samples']=len(diagnostic['rows'])
    verdict['diagnostic_fine_best_condition']=min(r['cond'] for r in diagnostic['rows'])
    verdict['diagnostic_fine_pass_samples']=sum(bool(r['passed']) for r in diagnostic['rows'])
   except Exception as exc:
    verdict['diagnostic_sweep_error']=repr(exc)
    log('DIAGNOSTIC_SWEEP_FAILED',error=repr(exc))
   return verdict
  mesh=independent_mesh(best['variant'],best,cal)
  if mesh['status']!='PASS':
   verdict.update(status='INDEPENDENT_MESH_GATE_FAILED',mesh=mesh)
   return verdict
  band=sample_band(best['variant'],best,cal,'FINE');bands=contiguous_band(band['rows'])
  verdict['verified_sampled_band_groups_GHz']=bands
  if not bands or not any(x['start_GHz']<=1.8<=x['stop_GHz'] for x in bands):
   verdict.update(status='FINE_BAND_GATE_FAILED',reason='Not at least 5 contiguous 25-MHz samples around 1.8GHz')
   return verdict
  extended=sample_band(best['variant'],best,cal,'EXTENDED')
  verdict.update(status='PERIODIC_HFSS_PASS_FINITE_PANEL_AND_HARDWARE_UNVERIFIED',
    success=True,extended_band_samples_passing=sum(r['passed'] for r in extended['rows']),
    reason='Simulated single-PCB ideal-switch periodic model only; not physical Rydberg measurement validation')
  return verdict
 except Exception:
  verdict.update(status='HFSS_OR_CAMPAIGN_EXECUTION_FAILED',reason=traceback.format_exc()[-12000:])
  return verdict
 finally:
  verdict['finished_utc']=now();save(R/'SCIENTIFIC_VERDICT.json',verdict)
  charts()
  try:package()
  except Exception:(L/'PACKAGE_FAILURE.txt').write_text(traceback.format_exc(),encoding='utf8')
  log('FINISHED',status=verdict['status'])

def cli():
 p=argparse.ArgumentParser();p.add_argument('action',choices=['run','preflight','pack'])
 a=p.parse_args()
 if a.action=='run':
  d=run();print(json.dumps(d,indent=2));return 0 if d.get('success') else 3
 if a.action=='preflight':
  create_cad();print('CAD_PREFLIGHT_PASS');return 0
 package();return 0
if __name__=='__main__':sys.exit(cli())
