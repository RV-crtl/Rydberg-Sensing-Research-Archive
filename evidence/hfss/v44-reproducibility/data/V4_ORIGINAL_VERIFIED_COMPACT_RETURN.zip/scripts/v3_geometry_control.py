"""V3 single 1.6mm PCB / exactly two copper faces and four genuine bridge gaps.

The shapes are *new design hypotheses*, inspired by the literature on U-FSS
and double-face cross-strip converters; they are not a replication of either paper.
Input dimensions are millimetres. Each bridge is a conductor if ON, open if OFF.
No diode impedance, bias network, vias, finite copper thickness or atomic model.
"""
from __future__ import annotations
import json,math,re
from pathlib import Path
from shapely.geometry import LineString,box,Polygon,MultiPolygon
from shapely.affinity import rotate,scale
from shapely.ops import unary_union
ROOT=Path(__file__).resolve().parents[1]
SAFE=re.compile(r'^[A-Za-z][A-Za-z0-9_]*$')

def config():return json.loads((ROOT/'config.json').read_text(encoding='utf8'))
def _poly(obj,z,layer,nm):
  if obj.is_empty:return []
  if obj.geom_type=='MultiPolygon':return sum((_poly(p,z,layer,nm+f'_{i:02d}') for i,p in enumerate(obj.geoms)),[])
  if obj.geom_type!='Polygon':raise ValueError(f'Unexpected Shapely geometry {obj.geom_type}')
  if obj.interiors: raise ValueError(f'Internal copper hole in {nm} - change polygon boolean')
  pts=[[float(a),float(b)] for a,b in list(obj.exterior.coords)[:-1]]
  if len(pts)<3 or obj.area<0.02:raise ValueError('Degenerate trace: '+nm)
  if not SAFE.fullmatch(nm):raise ValueError('HFSS invalid part name '+nm)
  if any(abs(x)>11.999 or abs(y)>11.999 for x,y in pts):raise ValueError('PCB unit cell out of bounds '+nm)
  return [{'name':nm,'z':z,'layer':layer,'polygon':pts,'area_mm2':float(obj.area)}]

def shapes(variant:int,mask:int,cfg=None):
  cfg=cfg or config();d=cfg['design']['variant_parameters'][variant];h=cfg['board']['thickness_mm'];gap=cfg['board']['nominal_switch_gap_mm']
  if not 0<=mask<=15:raise ValueError('Switch mask must be 0..15')
  X,Y=d['outer_x_mm'],d['outer_y_mm'];wt=d['front_width_mm'];wb=d['rear_width_mm']
  # Asymmetric open-ended front C / three-dipole U, selected around ~lambda_eff/2 path length.
  p_top=[(-X,-Y),(-X,Y),(X,Y),(X,-Y*0.65)]
  copper_top=LineString(p_top).buffer(wt/2,cap_style=2,join_style=2,quad_segs=4)
  # Two true gaps cut copper continuity; bridge states reconnect corresponding gaps.
  L=cfg['board']['switch_gap_along_trace_mm']
  top_gaps=[box(-X-gap/2,-L/2,-X+gap/2,L/2),box(2.3-L/2,Y-gap/2,2.3+L/2,Y+gap/2)]
  # Above 1st gap cuts vertical x=-X; second cuts top horizontal y=Y.
  # Rear: anti-symmetric three-dipole serpentine, transformed to introduce 3D chirality.
  rear_path=[(-X*.86,-Y*.9),(X*.8,-Y*.9),(X*.8,Y*.88),(-X*.65,Y*.88)]
  rear=LineString(rear_path).buffer(wb/2,cap_style=2,join_style=2,quad_segs=4)
  rear_gaps=[box(-L/2,-Y*.9-gap/2,L/2,-Y*.9+gap/2),box(X*.8-gap/2,-L/2,X*.8+gap/2,L/2)]
  # Nominal gap ALONG trace is 1.1mm; cut width ACROSS trace is 1.6mm.
  # Gap shapes use full contact cut -> OFF truly breaks trace and ON reconnects.
  # Switch pad box for ON always overlaps metal on both sides of each cut.
  rear=scale(rear,xfact=d.get('rear_scale',1.0),yfact=d.get('rear_scale',1.0),origin=(0,0))
  rear_gaps=[scale(g,xfact=d.get('rear_scale',1.0),yfact=d.get('rear_scale',1.0),origin=(0,0)) for g in rear_gaps]
  if d['rear_mirror']:
    rear=scale(rear,xfact=-1,yfact=1,origin=(0,0));rear_gaps=[scale(g,xfact=-1,yfact=1,origin=(0,0)) for g in rear_gaps]
  if d['rear_rotation_deg']:
    rear=rotate(rear,d['rear_rotation_deg'],origin=(0,0));rear_gaps=[rotate(g,d['rear_rotation_deg'],origin=(0,0)) for g in rear_gaps]
  top_cut=copper_top.difference(unary_union(top_gaps)); rear_cut=rear.difference(unary_union(rear_gaps))
  output=[]
  for j,part in enumerate(top_cut.geoms if top_cut.geom_type=='MultiPolygon' else [top_cut]):
    output+=_poly(part,h/2,'TOP',f'TOP_U_{j:02d}')
  for j,part in enumerate(rear_cut.geoms if rear_cut.geom_type=='MultiPolygon' else [rear_cut]):
    output+=_poly(part,-h/2,'BOTTOM',f'BOTTOM_U_{j:02d}')
  for bit,gap_shape in enumerate(top_gaps+rear_gaps):
    if mask & (1<<bit):
      orig=copper_top if bit<2 else rear
      # Restore exactly the region taken from the original trace; switch connection
      # is idealized PEC with zero series resistance and zero package reactance.
      bridge=orig.intersection(gap_shape.buffer(0.16,join_style=2))
      output+=_poly(bridge,h/2 if bit<2 else -h/2,'TOP' if bit<2 else 'BOTTOM',f'SWITCH_ON_{bit}')
  if len({p['name'] for p in output})!=len(output):raise ValueError('Duplicate HFSS names')
  return output

def u_baseline(cfg=None):
  """U inspired baseline (NOT exact 2021 published replication)."""
  cfg=cfg or config();d=cfg['design']['variant_parameters'][0];h=cfg['board']['thickness_mm'];X,Y=d['outer_x_mm'],d['outer_y_mm']
  p=LineString([(-X,-Y),(-X,Y),(X,Y),(X,-Y*.65)]).buffer(0.55,cap_style=2,join_style=2)
  return _poly(p,h/2,'TOP','TOP_U_BASELINE')

def get_shapes(design,variant,mask,cfg=None):
  if design=='EMPTY':return []
  if design=='U_BASELINE':return u_baseline(cfg)
  if design=='SINGLEPCB':return shapes(variant,mask,cfg)
  raise ValueError('unsupported design '+design)

def preflight():
  cfg=config();rows=[]
  for var in range(len(cfg['design']['variant_parameters'])):
    prev=None
    for mask in range(16):
      sh=shapes(var,mask,cfg)
      layers=sorted({x['layer'] for x in sh})
      if layers!=['BOTTOM','TOP']:raise ValueError('Two-face shape missing')
      if len(sh)>12:raise ValueError('Student-case excessive copper parts')
      if prev is not None and sh==prev:raise ValueError('State produced identical copper geometry')
      prev=sh
      rows.append({'design':'SINGLEPCB','variant':var,'mask':mask,'polygons':len(sh),
                   'top_mm2':round(sum(z['area_mm2'] for z in sh if z['layer']=='TOP'),3),
                   'bottom_mm2':round(sum(z['area_mm2'] for z in sh if z['layer']=='BOTTOM'),3)})
  rows.append({'design':'U_BASELINE','variant':0,'mask':0,'polygons':len(u_baseline(cfg))})
  rows.append({'design':'EMPTY','variant':0,'mask':0,'polygons':0})
  return rows

def svg(design,variant,mask,cfg=None):
  sh=get_shapes(design,variant,mask,cfg);p=['<svg xmlns="http://www.w3.org/2000/svg" width="840" height="840" viewBox="-12 -12 24 24">',
     '<rect x="-12" y="-12" width="24" height="24" fill="#e7edf3" stroke="#62748a" stroke-width="0.12"/>']
  for z in sh:
    pts=' '.join(f'{x:.5f},{-y:.5f}' for x,y in z['polygon']);color=('#ae6217' if z['layer']=='TOP' else '#227ca0')
    op='1.0' if z['layer']=='TOP' else '0.45'
    p.append(f'<polygon points="{pts}" fill="{color}" fill-opacity="{op}" stroke="#151f2a" stroke-width="0.04"/>')
  p.append('</svg>');return '\n'.join(p)

def dxf(design,variant,mask,cfg=None):
  sh=get_shapes(design,variant,mask,cfg)
  out=['0','SECTION','2','HEADER','9','$INSUNITS','70','4','0','ENDSEC','0','SECTION','2','ENTITIES']
  for e in sh:
    out+=['0','POLYLINE','8',e['layer'],'66','1','70','1']
    for x,y in e['polygon']:out+=['0','VERTEX','8',e['layer'],'10',str(round(x,7)),'20',str(round(y,7)),'30',str(e['z'])]
    out+=['0','SEQEND']
  return '\n'.join(out+['0','ENDSEC','0','EOF'])+'\n'
