"""Unchanged PyAEDT Floquet boundary and complex S-matrix methods from HFSS V2.1 real-success pipeline."""
from __future__ import annotations
import re, numpy as np
from physics import pack_jones
def fail(msg):raise RuntimeError(msg)
def mk_floquet(app, air, period, zmax, zmin):
    if not app.auto_assign_lattice_pairs(assignment=air.name):fail('Could not assign periodic X/Y lattice boundary pairs')
    p=period/2
    src=app.create_floquet_port(assignment=air.top_face_z,
               lattice_origin=[-p,-p,zmax],lattice_a_end=[p,-p,zmax],
               lattice_b_end=[-p,p,zmax],modes=2,name='SRC')
    if not src:fail('Top source Floquet port creation failed')
    dest=app.create_floquet_port(assignment=air.bottom_face_z,
               lattice_origin=[-p,-p,zmin],lattice_a_end=[p,-p,zmin],
               lattice_b_end=[-p,p,zmin],modes=2,name='DST')
    if not dest:fail('Bottom receiver Floquet port creation failed')

def frequency_values(stage, CFG, fine_center=None):
    f=CFG['frequencies_GHz']
    if stage=='SMOKE':return [float(f['smoke'])]
    if stage in ('DISCOVER','DISCOVER_REFINE'):return [1.8,2.15]
    if stage=='PILOT':return [round(f['pilot_start']+f['pilot_step']*j,8) for j in range(int(round((f['pilot_stop']-f['pilot_start'])/f['pilot_step']))+1)]
    if stage=='CORE':return [round(f['core_start']+f['core_step']*j,8) for j in range(int(round((f['core_stop']-f['core_start'])/f['core_step']))+1)]
    if stage=='BROAD':return [round(.3+.1*j,8) for j in range(58)]
    if stage in ('FINE','REFINE'):
       if fine_center is None:fail('fine_center required')
       cen=float(fine_center)
       return [round(cen-.1+.005*j,8) for j in range(41)]
    raise ValueError(stage)

def frequency_ghz(x,unit=None):
    if isinstance(x,str):
      match=re.match(r'^\s*([-+\d.eE]+)\s*(Hz|kHz|MHz|GHz)?\s*$',x,re.I)
      if not match:fail(f'Cannot parse HFSS sweep coordinate {x!r}')
      x=float(match.group(1));unit=match.group(2) or unit
    x=float(x)
    if unit:
      factor={'hz':1e-9,'khz':1e-6,'mhz':1e-3,'ghz':1.0}.get(str(unit).lower())
      if factor is None:fail(f'Unexpected sweep coordinate unit {unit!r}')
      return x*factor
    # Do not silently convert ambiguous numeric units.
    if 0.001<=x<=100.:return x
    if x>=1e8:return x/1e9
    fail(f'Unknown numeric HFSS Freq sweep scale {x}')

def fetch_matrix(app, solution_name, expected_freq):
    # Modal expressions MUST be actual complex S parameters, not dB(|S|).
    traces=list(app.get_traces_for_plot(category='S'))
    expected=[f'S(DST:{outmode},SRC:{inmode})' for outmode in (1,2) for inmode in (1,2)]
    normal=lambda s:re.sub(r'\s+','',str(s)).lower()
    choices={normal(t):t for t in traces}
    exprs=[]
    for name in expected:
        real_name=choices.get(normal(name))
        if real_name is None:
            fail('Missing FLOQUET modal expression '+name+'; available '+repr(traces[:70]))
        exprs.append(real_name)
    rows={};f_ref=None
    for name in exprs:
        d=app.post.get_solution_data(expressions=name,setup_sweep_name=solution_name,
                                     primary_sweep_variable='Freq',report_category='Modal Solution Data')
        if d is None:fail('No HFSS complex modal data for '+name)
        sweeps=getattr(d,'primary_sweep_values',None)
        if sweeps is None: sweeps=d.sweeps.get('Freq')
        unit=getattr(d,'units_sweeps',{}).get('Freq') if hasattr(d,'units_sweeps') else None
        f=np.array([frequency_ghz(q,unit) for q in sweeps],float)
        real=np.asarray(d.data_real(name),float)
        imag=np.asarray(d.data_imag(name),float)
        if len(f)!=len(real) or len(real)!=len(imag):fail('Incomplete complex data '+name)
        if f_ref is None:f_ref=f
        if len(f)!=len(f_ref) or np.max(abs(f-f_ref))>1e-5:fail('Inconsistent frequency coordinates '+name)
        rows[name]=real+1j*imag
    if not np.isfinite(f_ref).all():fail('Nonfinite frequency output')
    for x in expected_freq:
      if np.min(abs(f_ref-x))>0.0002:fail(f'Missing requested HFSS frequency {x} GHz')
    # Output used only at genuinely solver-returned frequencies.
    out=[]
    for i,f in enumerate(f_ref):
      j=np.array([[rows[exprs[0]][i],rows[exprs[1]][i]],
                  [rows[exprs[2]][i],rows[exprs[3]][i]]],complex)
      if not np.isfinite(j).all():fail('Nonfinite transmission matrix at '+str(f))
      # A two-port, two-mode periodic solution should conserve/passively dissipate power.
      rho=float(np.linalg.eigvalsh(j.conj().T@j).max().real)
      if rho>1.05:fail(f'Non-passive S matrix |T|²max={rho:.3g} at {f:.3f} GHz; investigate mode normalization')
      out.append({'frequency_GHz':float(f),'t_jones_2x2_complex':pack_jones(j),
                  'max_transmitted_power_eigenvalue':rho})
    return out,exprs

