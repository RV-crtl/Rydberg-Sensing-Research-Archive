"""OPTIONAL V4 NATIVE HFSS 7x7 finite panel / plane-wave / ROI E-field export.

Requires a successful science-gated periodic campaign. Uses the same copper
polygons but repeats them 49 times within a 178mm board. Results NOT treated
as polarimetric EIT response until raw field files are independently checked.
"""
from __future__ import annotations
import json,sys,os,traceback,hashlib,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from pcb_geometry import config,shapes
C=config();H=C['hardware'];B=C['board'];OUT=ROOT/'HFSS_FINITE_ROI';OUT.mkdir(exist_ok=True)
def write(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(d,indent=2,allow_nan=False,default=str)+'\n',encoding='utf8')
def single_case(var,mask,pol):
 freq=H['primary_GHz'];n=B['cells_x'];cell=B['unit_cell_mm'];outline=B['panel_outline_mm'];h=B['thickness_mm']
 ident=f'FINITE_V{var:02d}_M{mask:02d}_{pol}'
 folder=OUT/ident;folder.mkdir(exist_ok=True,parents=True)
 meta={'case':ident,'physical_panel_mm':[outline,outline,h],
  'copper_pattern_mm':[n*cell,n*cell],'aperture_mm':H['sensor_roi_mm'],
  'source':'NATIVE_FINITE_PANEL_ANSYS_HFSS',
  'warning':'Plane wave surrogate; not LPDA excitation, not calibrated EIT; student edition may run out of mesh cells',
  'polarization':pol,'incident_direction':'-z','z_receiver_near_mm':-15-h/2}
 write(folder/'START.json',meta)
 app=None
 try:
  from ansys.aedt.core import Hfss
  app=Hfss(project=str(folder/(ident+'.aedt')),design='FINITE_SEVEN_BY_SEVEN',
      solution_type='Modal',version=C['aedt_version'],non_graphical=False,new_desktop=True,
      close_on_exit=False,student_version=any(os.environ.get(k) for k in
      ('ANSYSEMSV_ROOT252','ANSYSEMSV_ROOT251','ANSYSEMSV_ROOT261','ANSYSEMSV_ROOT242')))
  app.modeler.model_units='mm'
  material=app.materials.add_material('RO4350B_EQUIVALENT')
  material.permittivity=B['epsilon_r'];material.dielectric_loss_tangent=B['tan_delta']
  app.modeler.create_box([-outline/2,-outline/2,-h/2],[outline,outline,h],
       material='RO4350B_EQUIVALENT',name='ONE_PCB_178MM')
  one=shapes(var,mask,C)
  for row in range(n):
   for col in range(n):
    offset_x=(col-(n-1)/2)*cell;offset_y=(row-(n-1)/2)*cell
    for elem in one:
     pts=[[x+offset_x,y+offset_y,elem['z']] for x,y in elem['polygon']]
     name=f'R{row}C{col}_'+elem['name']
     p=app.modeler.create_polyline(pts,close_surface=True,cover_surface=True,
              name=name,material='vacuum')
     if not p or not app.assign_perfect_e(p.name,name='PEC_'+name):
       raise RuntimeError('HFSS finite copper/PEC error at '+name)
  if not app.create_open_region(f'{freq}GHz',boundary='Radiation'):
   raise RuntimeError('Could not create open-region radiation boundary')
  direction=[1,0,0] if pol=='H' else [0,1,0]
  if not app.plane_wave(vector_format='Cartesian',polarization=direction,
      propagation_vector=[0,0,-1],origin=[0,0,0],name='PW_'+pol):
   raise RuntimeError('HFSS plane wave excitation failed')
  setup=app.create_setup('Setup1');setup.props['Frequency']=f'{freq}GHz'
  setup.props['MaximumPasses']=12;setup.props['MinimumPasses']=5
  setup.props['MaxDeltaS']=.025;setup.update()
  app.save_project()
  if not bool(app.validate_simple()):raise RuntimeError('Finite ROI solver validation returned false')
  if app.analyze() is False:raise RuntimeError('Finite ROI HFSS solution failed')
  z_near=-15-h/2;z_far=z_near-10
  fn=folder/'HFSS_E_FIELD_COMPLEX.fld'
  result=app.post.export_field_file_on_grid(quantity='E',solution='Setup1 : LastAdaptive',
    variations=app.available_variations.nominal_values,file_name=str(fn),grid_type='Cartesian',
    grid_start=[-35,-25,z_far],grid_stop=[35,25,z_near],grid_step=[7,50/14,2.5],
    is_vector=True,intrinsics={'Freq':f'{freq}GHz','Phase':'0deg'},export_in_si_system=False)
  if not result or not fn.exists() or fn.stat().st_size<1000:raise RuntimeError('Native HFSS E field export missing')
  meta.update(status='HFSS_SOLVED_AND_RAW_E_FIELD_EXPORTED',bytes=fn.stat().st_size,
              sha256=hashlib.sha256(fn.read_bytes()).hexdigest(),result=str(fn))
  write(folder/'RESULT.json',meta)
  return 0
 except Exception as e:
  meta.update(status='HFSS_FINITE_FAILED',error=repr(e),traceback=traceback.format_exc())
  write(folder/'CASE_FAILURE.json',meta);print(meta['traceback'],flush=True)
  return 2
 finally:
  if app:
   try:app.save_project()
   except Exception:pass
   try:app.release_desktop(close_projects=True,close_desktop=True)
   except Exception:pass

def main():
 p=ROOT/'RESULTS'/'SCIENTIFIC_VERDICT.json'
 if not p.exists():print('FINITE SKIPPED: periodic HFSS campaign not completed');return 3
 verdict=json.loads(p.read_text())
 if not verdict.get('success'):
  print('FINITE SKIPPED: no physics-gate-passing periodic candidate found');return 3
 var=verdict['best_variant'];masks=verdict['best_states']
 for m in masks:
  for pol in ('H','V'):
   res=single_case(var,m,pol)
   if res:return res
 print('FINITE HFSS fields exported; inspect raw complex field data and add reference calibration before Stokes claims')
 return 0
if __name__=='__main__':sys.exit(main())
