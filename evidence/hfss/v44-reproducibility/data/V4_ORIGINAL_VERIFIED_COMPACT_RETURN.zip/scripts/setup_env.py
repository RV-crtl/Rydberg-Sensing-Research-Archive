"""Environment bootstrap with visible pip output and cached venv; Python stdlib only."""
import os,sys,subprocess,traceback,zipfile,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
ENV=ROOT/'.venv';PY=ENV/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
LOG=ROOT/'LOGS';LOG.mkdir(exist_ok=True)
def go(args,title):
 print('RUNNING:',title,flush=True)
 with (LOG/(title+'.log')).open('a',encoding='utf8') as out:
  p=subprocess.Popen([str(x) for x in args],cwd=ROOT,stdout=subprocess.PIPE,
                     stderr=subprocess.STDOUT,encoding='utf8',errors='replace',bufsize=1)
  for line in p.stdout:print(line.rstrip(),flush=True);out.write(line);out.flush()
  return p.wait()
def main():
 try:
  if sys.version_info[:2]!=(3,11):raise RuntimeError('Use 64-bit Python 3.11. This package was targeted at Python 3.11.')
  if not PY.exists():
   if go([sys.executable,'-m','venv',str(ENV)],'CREATE_VENV'):raise RuntimeError('Failed to create Python environment')
  checker=[str(PY),'-c','import numpy,matplotlib,pandas; from ansys.aedt.core import Hfss; print("PYAEDT_IMPORT_PASS")']
  if go(checker,'INITIAL_IMPORT_CHECK')==0:return 0
  if go([str(PY),'-m','pip','install','--disable-pip-version-check','--prefer-binary',
       '--retries','2','--timeout','40','-r',str(ROOT/'requirements.txt')],'PIP_INSTALL'):
   raise RuntimeError('Pip install failed: inspect LOGS/PIP_INSTALL.log')
  if go(checker,'FINAL_IMPORT_CHECK'):raise RuntimeError('PyAEDT import still failed after installation')
  return 0
 except Exception:
  (LOG/'SETUP_FATAL.txt').write_text(traceback.format_exc())
  print(traceback.format_exc(),flush=True)
  # diagnostic ZIP works before any external dependency has installed
  out=ROOT/'RETURN_PACKAGES'/('RETURN_TO_CHATGPT_SETUP_FAILURE_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
  out.parent.mkdir(exist_ok=True)
  with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
   for f in LOG.glob('*'):
    if f.is_file():z.write(f,'LOGS/'+f.name)
   for f in [ROOT/'config.json',ROOT/'requirements.txt']:
    z.write(f,f.name)
  print('SETUP DIAGNOSTICS:',out,flush=True)
  return 2
if __name__=='__main__':sys.exit(main())
