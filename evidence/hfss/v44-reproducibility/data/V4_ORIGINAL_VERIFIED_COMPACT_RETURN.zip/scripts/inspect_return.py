"""Standard-library-only return ZIP verifier and safe, optional extractor."""
import sys,json,zipfile,hashlib,argparse
from pathlib import Path

def validate_zip(path):
 path=Path(path)
 with zipfile.ZipFile(path,'r') as z:
  bad=z.testzip()
  if bad:raise RuntimeError('ZIP CRC FAILED: '+bad)
  names=z.namelist();name_set=set(names)
  if 'SHA256_MANIFEST.json' not in name_set:raise RuntimeError('Missing SHA256_MANIFEST.json')
  hashes=json.loads(z.read('SHA256_MANIFEST.json'))
  for n,sha in hashes.items():
   if n not in name_set:raise RuntimeError('Missing ZIP member '+n)
   if hashlib.sha256(z.read(n)).hexdigest()!=sha:raise RuntimeError('SHA256 mismatch '+n)
  verdict={}
  if 'READ_ME_FIRST_RETURN_SUMMARY.json' in names:
   verdict=json.loads(z.read('READ_ME_FIRST_RETURN_SUMMARY.json')).get('verdict',{})
  return {'status':'VALID','zip':str(path),'members':len(names),'sha256_entries':len(hashes),
          'verdict_status':verdict.get('status','UNKNOWN'),'science_pass':verdict.get('success',False)}

def main():
 p=argparse.ArgumentParser();p.add_argument('path',nargs='?');p.add_argument('--extract-to',default=None)
 a=p.parse_args()
 if a.path:found=[Path(a.path)]
 else:found=sorted((Path(__file__).resolve().parents[1]/'RETURN_PACKAGES').glob('*COMPACT*.zip'),reverse=True)
 if not found:raise RuntimeError('No return ZIP found; specify a path')
 output=validate_zip(found[0]);print(json.dumps(output,indent=2))
 if a.extract_to:
  dest=Path(a.extract_to).resolve();dest.mkdir(parents=True,exist_ok=True)
  with zipfile.ZipFile(found[0]) as z:
   for member in z.infolist():
    target=(dest/member.filename).resolve()
    if not target.is_relative_to(dest):raise RuntimeError('Unsafe zip path '+member.filename)
   z.extractall(dest)
  print('Safely extracted verified archive to',dest)
 return 0
if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:print('RETURN_ARCHIVE_INVALID:',repr(e),file=sys.stderr);sys.exit(2)
