@echo off
setlocal EnableExtensions DisableDelayedExpansion
REM Keep a second command interpreter open so Windows Explorer never hides errors.
REM /K deliberately remains open after setup, scientific FAIL (code 3), or a crash.
if /I not "%~1"=="--V4-INNER" (
    "%ComSpec%" /D /K call "%~f0" --V4-INNER
    exit /b %ERRORLEVEL%
)
title Rydberg Single-PCB HFSS V4.1 - 1.8 GHz - Persistent Console
pushd "%~dp0"
if errorlevel 1 (
    echo ERROR: Cannot enter extracted project directory.
    exit /b 4
)
if not exist "LOGS" mkdir "LOGS"
if not exist "RETURN_PACKAGES" mkdir "RETURN_PACKAGES"
echo ================================================================
echo  RYDBERG HFSS V4.1 - 1.8 GHz SIMULATION

echo  Project: %CD%
echo  This console remains OPEN after every failure or completion.
echo  Scientific FAIL [exit 3] is not an installation error.
echo ================================================================
echo.
set "V4_RUN_PY="
where py >nul 2>nul
if not errorlevel 1 set "V4_RUN_PY=py"
if defined V4_RUN_PY goto RUN_WITH_PY
where python >nul 2>nul
if not errorlevel 1 goto RUN_WITH_PYTHON
where python3 >nul 2>nul
if not errorlevel 1 goto RUN_WITH_PYTHON3
 echo ERROR: No Python executable discovered on PATH.
 echo Install Python 3.11 x64 from python.org, with the Python launcher or PATH enabled.
 echo For recovery, see README_LAUNCH_FIX.md and upload LOGS if present.
 set "RUN_RC=4"
 goto END_RUN
:RUN_WITH_PY
py -3 -u scripts\launcher_v4.py run
set "RUN_RC=%ERRORLEVEL%"
goto END_RUN
:RUN_WITH_PYTHON
python -u scripts\launcher_v4.py run
set "RUN_RC=%ERRORLEVEL%"
goto END_RUN
:RUN_WITH_PYTHON3
python3 -u scripts\launcher_v4.py run
set "RUN_RC=%ERRORLEVEL%"
:END_RUN
echo.
echo =================== FINISHED ==================================
echo Exit status: %RUN_RC%
echo If setup failed, send RETURN_PACKAGES\RETURN_TO_CHATGPT_V4_STARTUP_FAILURE_*.zip
echo If simulations ran, send RETURN_PACKAGES\RETURN_TO_CHATGPT_SINGLEPCB_V4_COMPACT_*.zip
echo Logs are in LOGS. This console will remain open until you close it.
echo =================================================================
popd
exit /b %RUN_RC%
