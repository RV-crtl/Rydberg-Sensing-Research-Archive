@echo off
setlocal
call "%~dp0RUN_AUTOMATIC.cmd"
exit /b %ERRORLEVEL%
