# Published optical windmill versus the L-band PCB adaptation

## Actual optical source

Yi-Ming Liu et al., *Giant Chirality in Hybrid Perovskite Metasurfaces via a Universal van der Waals Dry Transfer Strategy*, **ACS Applied Nano Materials** 9 (2026) 14112–14120, DOI **10.1021/acsanm.6c00818**.

Their Figures 1–6 report near-infrared gold windmill metasurfaces transferred onto perovskite films, not an L-band PCB. Figure 2 specifies **p=776nm, l=420nm, a=140nm, h=100nm**. Experimental and simulated spectra are in the **900–1300nm** region. Their device's strong optical CD relies on resonant plasmonic and dielectric-interface phenomena, discussed using electric/magnetic mode contributions.

The user-uploaded Ansys figures labeled wavelength in nm belong to that optical regime. NEVER label them GHz, and never claim their optical CD/g-factor values describe a scaled copper PCB.

## Why a literal scaling claim would be invalid

At 1.85GHz λ0≈162.05mm. Keeping paper p/λ≈776/1153 implies p≈109mm and l≈59mm, a≈19.7mm; however matching paper metal height h/λ would require ~14mm, wildly incompatible with a PCB's proposed 35µm copper. Their optical metallic/perovskite refractive response does not scale into microwave copper/dielectric response. A 178–200mm board would also hold only approximately two cells across at the naive paper-normalised period, unlike the 7x7, 24mm optimized split-loop device.

A manufacturable *inspired* adaptation can preserve **p:l:a** ratio but its performance must be solved afresh with HFSS and independently demonstrated.

## The V4.18 test programme

1. Construct a C4 hooked-arm interpretation consistent with p:l:a (paper nominal proportions), two mirrored handedness variants, ideal PEC sheet on 1.6mm RO4350B-equivalent PCB.
2. HFSS Floquet screen at p=40, 60, 100mm over 1.0–2.0GHz; save all complex Jones coefficients and L/R transmittance spectra; compare handedness reversal. No simulated RF result is available until this stage has run in Ansys.
3. Construct a 200x200mm, 2x2, 90mm-pitch, 10mm-margin finite PCB windmill, and solve two opposite handedness variants plus empty reference under X and Y incident plane waves.
4. Export TOTAL complex electric fields at 70x50mm receiver ROI, z=5,10,20,50mm; use exact complex linear superposition to derive H/V/D/A/R/L mean squared amplitudes, and measure how R/L contrast varies with distance. Do not confuse this with atomic EIT measurement.
5. Keep original earlier paper-replication screenshots and adapted figures in the historical image folder as **prior evidence snapshots**, not new V4.18 simulation results.

## What "replication" means here

The source PDF does not supply a machine-readable HFSS/COMSOL CAD solid or the measured dispersive complex dielectric functions in the screenshot alone. Therefore V4.18 provides a *documented RF windmill-style CAD hypothesis* and compares its response against the previously modelled adaptation and the optimized split-loop. It does NOT claim geometrically exact replication of their native optical CAD or reproduce the published 7000mdeg experimental signal.

## PCBWay readiness boundary

A copper pattern and two-layer 178x178mm, 1.6mm PCB stackup with >0.75mm copper gaps and >0.8mm traces is potentially manufacturable, but a shipped reconfigurable PCB additionally needs pads, diode BOM, device ON/OFF impedances, bias routing and DRC/Gerber validation. The current ideal PEC-bridge implementation is *not* a complete PCBWay fabrication package.

## Paper usage

Narrative: published windmill optical inspiration → previous attempted 200mm microwave adaptation and observed distance-sensitive circular discrimination → new independent windmill L-band tests → superior validated six-state C000/C033/C015 optimisation (if the simulations actually demonstrate superiority). Explicitly separate **polarisation generation**, **circular dichroism**, **full-Stokes reconstruction** and **atomic optical sensing**.
