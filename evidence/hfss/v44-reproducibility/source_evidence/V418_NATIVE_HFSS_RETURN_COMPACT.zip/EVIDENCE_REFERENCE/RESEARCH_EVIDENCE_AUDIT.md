# Independent audit — V4.16 (two uploaded HFSS returns)

**Outcome:** completed 36/36 interpolating-sweep screens, with 35 new candidate geometries and zero global campaign failures. Top candidates **C033 and C015 both pass 1.750–2.000 GHz at 25 MHz sampled spacing**, equivalent to 11 samples and a 250 MHz sampled span. The original geometry passed 1.825–2.000 GHz, eight samples, 175 MHz.

**Relative expansion:** (250−175)/175 × 100 = **42.9%**. This is a comparison of **sampled interpolated HFSS screens**. It is not a measured or independently confirmed continuous operating bandwidth.

## Independent single-frequency HFSS results

| Design | GHz | Finer-mesh condition | Matrix change (%) | Deterministic transfer (%) | Strict gate |
|---|---:|---:|---:|---:|---|
| C033 | 1.750 | 34.62 | 0.560 | 4.83 | PASS |
| C033 | 1.875 | 15.20 | 0.577 | 11.27 | FAIL |
| C033 | 1.925 | 9.53 | 0.551 | 5.01 | PASS |
| C033 | 2.000 | 26.58 | 0.722 | 12.64 | FAIL |
| C015 | 1.750 | 33.59 | 2.283 | 26.47 | FAIL |
| C015 | 1.875 | 19.44 | 0.995 | 29.20 | FAIL |
| C015 | 1.950 | 8.64 | 0.325 | 2.42 | PASS |
| C015 | 2.000 | 18.69 | 0.770 | 7.12 | PASS |

The failed cases have individually converged rank-4 analysers, but breach the earlier specified 10% **deterministic cross-mesh Stokes calibration-transfer** criterion. The new V4.17 report displays **electromagnetic screening** and **strict transfer** separately. It does not change any HFSS results or pretend a failed strict gate is a pass.

## Most promising direction

Keep **C033** as the principal bandwidth candidate. It achieves full-Stokes conditioning under 35 across the predicted sampled region and already passes independent confirmation at 1.750 and 1.925 GHz. Keep **C015** for its very promising 1.950–2.000 GHz performance. The original **C000** remains the already-established design baseline.

## Critical publication evidence gaps

1. Complete adapted-frequency HFSS grid across the proposed optimum bandwidth, then bracket both operating edges.
2. Correctly labelled interpolated / adapted / finite-field plots, with every complex coefficient exported.
3. Geometry and optimisation comparison, convergence history, singular values, circular response and analyser vectors.
4. 7×7 finite-panel six-state analysis (still absent; previous 3×3 single-state finite result must not be represented as full analyser).
5. A defensible connection between the RF analyser and a Rydberg EIT/AT optical observable, **if** making atom-sensor-specific claims.
6. Original linear laboratory raw traces across runs and context for circular-polariser precursor.
7. Verify originality of each project-derived equation against literature.
8. Archive the complete native `.aedt`/`.aedtresults` directories separately; **they are not inside the compact return ZIP**.

No artificially injected noise or fabricated HFSS data is used.
