# V4.18 — Comprehensive HFSS scientific evidence campaign

**Primary goal:** complete the HFSS-native data behind the original C000, optimized C033 and C015 single-PCB polarization analyzers; verify the project's mathematical relations directly against the native HFSS 2×2 complex Jones coefficients; simulate complete six-state finite receiver fields; and evaluate a *distinct* PCB reinterpretation of the published windmill chiral metasurface.

This is a **PATCH** for the ORIGINAL V4.1 / V4.16 fully completed Windows working folder. It does not contain Ansys software, does not invent HFSS output, and must not be placed into an empty directory. **Do not delete or overwrite** your existing `.aedt` or `.aedtresults` data.

## Start here

1. Back up the complete V4.16 Windows folder, including `V416_HFSS_PROJECTS` and `V416_CANDIDATES`.
2. Extract this ZIP into that same folder, merging `scripts`. It includes V4.17's continuation script/config, allowing independent optimized-band confirmation even if you haven't previously installed V4.17. It preserves V4.16 source files.
3. Run **`RUN_V418_PREFLIGHT.cmd`**. This tests 3 candidate geometries, validates the paper-inspired geometry, checks reference HFSS results, and creates preliminary proof/geometry/Poincaré figures.
4. Run **`RUN_V418_ALL_AUTOMATIC.cmd`**. This can take *a long time*. It sequentially executes:
   - Native dual-mesh HFSS targeted-frequency confirmation for C033/C015, reusing any previous V4.16/V4.17 native solves.
   - Periodic full Jones-matrix simulations at 1.0–2.0 GHz for 3 windmill cell periods, each R/L mirror version plus 3 references (9 HFSS cases).
   - Nonperiodic finite 3x3 (82mm) direct HFSS total-field solves for six switch states under X and Y inputs, for C033 AND C000 (24 HFSS cases), sampled over 70x50 mm at z=5,10,20,50mm.
   - A 2x2 **200x200mm** windmill PCB, for BOTH handednesses plus a reference under X/Y incidence (6 more HFSS cases).
   - A machine-readable final evidence audit. All completed results are retained and return archives saved after each major stage.
5. Upload the newest `RETURN_TO_CHATGPT_V418_*.zip` from `RETURN_PACKAGES`. If the job stops, send the return ZIP even if some cases are incomplete. Read `V418_CAMPAIGN_STATE.json` for the failed stage.
6. Run **`RUN_V418_BACKUP_ALL_NATIVE.cmd`** to archive full `.aedt` and `.aedtresults` projects separately, potentially **many gigabytes**. These native projects remain locally on disk even without running the backup.

Optional, potentially resource intensive:
- `RUN_V418_C015_FINITE_OPTIONAL.cmd`: full C015 six-state finite X/Y comparison.
- `RUN_V418_7X7_FINITE_OPTIONAL.cmd`: 178x178mm, 7x7 full physical panel; likely to exceed the Student volume mesh cap. It is separate to avoid prematurely stopping the main campaign.
- `RUN_V418_REPORT_ONLY.cmd`: regenerate all available scientific data outputs/plots and pack without new HFSS solves.

## Scientific provenance

- Optically published reference: Liu et al., *Giant Chirality in Hybrid Perovskite Metasurfaces via a Universal van der Waals Dry Transfer Strategy*, ACS Applied Nano Materials **9**, 14112-14120 (2026), DOI: **10.1021/acsanm.6c00818**. Source paper's geometry nominal p=776nm, l=420nm, a=140nm, h=100nm, near-IR λ~900–1300nm.
- Earlier user screens capture a near-IR paper HFSS model, a 200mm L-band adaptation and near-field circular discrimination. They are **archived as user-supplied historical images**. Their curves are not newly calculated V4.18 HFSS data.
- V4.18's windmill is a **paper-ratio-inspired C4 hooked-arm CAD interpretation**, not a verified exact import of authors' native CAD. Its RF 1.6mm printed circuit, ideal copper, and dielectric are not the same physics or materials as gold/perovskite optical plasmonics. The 200mm adapted windmill is compared separately with the C033/C000 split-loop analyser. Success must come from its *new HFSS spectra*, not scaling expectations.
- The original six-state split-loop model assumes periodic Floquet, ideal zero-thickness PEC and ideal closed/open bridge contacts. The finite model uses plane waves and nonperiodic radiation boundaries.
- `V418_RESULTS/DATA/V418_EQUATION_AUDIT.json` checks *the algebraic consistency of native Jones matrices*, not new universal physical laws. Exact synthetic input Jones vectors are used strictly to evaluate the already solved linear electromagnetic operator; NO fake HFSS data, synthetic noise, or empirical calibration is added.
- `V418_RESULTS/FINITE/*` contains **native total E** for six masks under X/Y incidence and derived 70×50mm receiver-weighted quadratic Stokes rows. The chosen X detector is only an example response model, not a measured Rydberg EIT readout.
- Numerical full-rank and Poincaré reconstruction are HFSS-derived electromagnetic/inversion results, **not guaranteed finite PCB or atomic measurement results**.
- The phrase "sampled full-Stokes bandwidth" is never silently promoted to "continuous operating bandwidth". Native independent-frequency and native convergence evidence are retained separately.
- The new geometry is manufacturability-oriented (2 copper faces, 1.6mm PCB, min trace and gap from V4.16), but **ideal bridge switches are not actual PCBWay PIN diode footprints and bias routing**. Gerber/BOM and a PCB DRC would be required before claiming fabrication readiness.

## Data preservation

- Existing original native projects under `V416_HFSS_PROJECTS` are reused and **never overwritten**.
- New native projects stored under `V418_NATIVE_HFSS` and saved with solution folders.
- All available numeric `RESULT.json`, `ADAPTIVE_EVIDENCE/*.conv/*.prof/*.mesh`, solver messages, native complex Jones coefficients, receiver `.fld` vectors, CSV Stokes rows, SVG/PDF/PNG scientific figures, optimizer configurations and output logs are included in the compact return when size permits.
- Native `.aedt` and `.aedtresults` excluded from compact return to avoid huge ZIP; run separate full-native backup.
- SHA256 manifest is verified on return ZIP creation, failing loudly if corrupted.

## In the event of failure

The campaign stops on a native solver failure (e.g. 64,000-element Student cap or unsupported AEDT boundary API), writes the failing native messages and case failure JSON, packs all completed data and preserves projects. Re-running never silently overwrites failed project files. Return the ZIP to ChatGPT and fix the failing case first. Do not repeatedly increase mesh size without convergence diagnostics.

## Prioritised journal figure inventory

See `JOURNAL_EVIDENCE_MASTER_CHECKLIST.md` and machine-readable `V418_RESULTS/V418_EVIDENCE_LEDGER.json`; incomplete entries remain explicitly MISSING, not fictitiously filled.

**Offline release QA:** 18 native-data regression checks passed, automatic report generation and checksum-verified return ZIP passed, and an intentional no-AEDT test produced an error ZIP with failure diagnostics. No newly requested HFSS electromagnetic solves have been performed here.

**V4.17 compatibility correction:** the V4.16 native confirmation solver supports 1.0–2.0 GHz only. This V4.18 patch removes the earlier optional 2.025 GHz attempts, which that solver would otherwise reject before HFSS. The 2.0 GHz edge remains within the campaign; extension beyond 2.0 GHz needs a separately extended native solver and is not silently claimed here.
