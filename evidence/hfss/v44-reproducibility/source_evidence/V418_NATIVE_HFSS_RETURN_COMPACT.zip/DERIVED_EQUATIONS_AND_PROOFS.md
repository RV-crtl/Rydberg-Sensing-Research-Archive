# Project-derived equation programme — precise proofs and native HFSS tests

No claim is made that standard Jones/Stokes, Fresnel diffraction or Gram matrix identities are newly discovered physical laws. The contribution is their **application-specific derivation, parametrisation and numerical validation** for this six-state single-PCB metasurface sensing geometry.

## E1: HFSS complex-Jones to receiver-Stokes operator

For each switch state k at frequency f, HFSS supplies the 2x2 complex transmission matrix J_k. Using a fixed X receive projection and a consistent empty-cell modal-frame normalization U0, the 1x2 row is (u_k,v_k)=e_x^T U0^† J_k. For Jones incident vector (a,b)^T,

    m_k = |u_k a + v_k b|^2.

The Stokes convention throughout this project is:

    S0 = |a|²+|b|², S1=|a|²-|b|²,
    S2=2 Re(a conj(b)), S3=2 Im(a conj(b)).

Let P=|u|², Q=|v|², C=conj(u) v. Then

    m_k = ((P+Q)/2) S0 + ((P-Q)/2) S1 + Re(C) S2 + Im(C) S3.

Thus each switch provides A_k=[(P+Q)/2,(P-Q)/2,Re(C),Im(C)].

**V4.18 HFSS evidence:** compute A from native HFSS Jones J, then compare A S with the direct complex-amplitude prediction |u a + v b|² for H/V/D/A/R/L and >1000 Poincaré input states. Report absolute residual and full raw values in candidate `POINCARE_*.csv`.

**Important distinction:** this is a consistency check on one HFSS-linear-response representation, not an independent new HFSS solve for each Poincaré sphere point.

## E2: Gram positivity, feasibility and information coverage

Q=[[P,C],[conj(C),Q]] is positive semidefinite, so |C|²≤P Q. Therefore

    A0² - A1² - A2² - A3² = P Q - |C|² ≥0,

and |(A1,A2,A3)|≤A0 for each real receiver state. For a purely local rank-1 projection equality holds; spatial averaging over the ROI can make it strict.

**V4.18 tests:** compute residual for all six states at three chosen native HFSS frequencies. The finite 70x50mm integral (uniform spatial sample mean) provides a genuinely different Gram averaging test, if native finite solves complete.

## E3: Full-Stokes uniqueness and pseudoinverse

With six state rows A in R^{6x4}, rank(A)=4 is necessary/sufficient for ideal noiseless linear uniqueness:

    m=A S and S_hat=A^+m.

If rank<4 a nonzero null vector n obeys An=0; S and S+cn are indistinguishable (with a physically admissible perturbation if possible). When rank=4 the Moore-Penrose inverse recovers ideal Stokes.

**V4.18 tests:** rank, four singular values, normalized condition, and dense full Poincaré algebraic inversion. Finite-panel inversion separately uses native X/Y total fields integrated over the 70x50mm ROI; do not conflate periodic and finite matrices.

## E4: Signed circular-power discrimination

Define R=(1,-i)/sqrt(2) with S3=+1 and L=(1,+i)/sqrt(2) with S3=-1 (labels depend on view and phase convention). For fixed switched state:

    m_R=A0+A3, m_L=A0-A3,
    (m_R-m_L)/(m_R+m_L)=A3/A0.

**V4.18 tests:** direct transmitted Jones-amplitude intensities for R/L versus predicted A3/A0; and native mirrored windmill RF HFSS spectra with total output power rather than X receiver only.

The windmill `g_T=2(T_L-T_R)/(T_L+T_R)` is a TRANSMITTANCE asymmetry factor, not necessarily the optical paper's logarithmic absorbance-based g_CD.

## E5: Bandwidth set, not transmission-only width

For a fixed HFSS model define at each frequency f:

    valid(f)=[rank(A_f)=4] and [kappa(A_f)<=35]
             and [min_k(A_k0)>=0.015]
             and [max_k(A_k3/A_k0)-min_k(A_k3/A_k0)>=0.08].

The sampled passing span is max_{contiguous on measured grid} (f_high-f_low). Interpolated sweeps are discovery-only; independent adaptive solves near the band and peak validate specific samples.

**V4.18 tests:** C000/C033/C015 41-point HFSS spectra and the full V4.17 independent-frequency continuation. Native S coefficients and four singular values are preserved. No claiming unsampled frequencies.

## E6: Aperture parameterisation and empirically tested spatial change

In free space λ0=c/f and Fresnel number F=a²/(λ0 z) for characteristic half-aperture a and observation distance z. This is a **standard diffraction descriptor**, not a law that guarantees a minimum useful aperture.

**V4.18 tests:** report F at 82,178,200mm apertures and 5/10/20/50mm, and directly compare the HFSS *spatial* ROI analyzer rows for the finite 3x3 C000/C033 and the adapted 200mm windmill at those planes. Bandwidth and polarimetric rank may change with finite geometry; no extrapolation from F alone.

## E7: Missing circular dimension in any equatorial-only linear analyser

For a unit normalized fully polarized Stokes vector s on a Poincaré sphere with azimuth ψ and ellipticity χ:

    (s1,s2,s3)=(cos2χ cos2ψ, cos2χ sin2ψ, sin2χ).

Projection to the nearest linear-equator point gives geodesic separation |2χ| for |χ|≤π/4. This follows directly from the spherical geometry, not a newly invented law.

**V4.18 role:** motivates the project progression experimental linear device → circular device → full six-state rank-4 metasurface. Does NOT imply a finite practical accuracy bound.
